# Putting EnergyMonitor online at energy.lowkeypeek.com

Plan: host the app on **Render** (free to start), then point a GoDaddy subdomain at it.
Vercel will not work: this app is a server that keeps running and keeps live state in memory.

## 0. What you need
- A free GitHub account and a free Render account (render.com). You create these yourself.
- Access to your GoDaddy account for lowkeypeek.com.

## 1. Put the project on GitHub
1. On github.com click **New repository**, name it `energy-monitor`, keep it **Private**, click Create.
2. On the empty repo page click **uploading an existing file**.
3. Unzip the project on your Mac. Open the `energy-monitor` folder and drag in everything EXCEPT `node_modules` and `legacy`
   (Render installs the packages itself). Click **Commit changes**.

## 2. Create the service on Render
1. In Render click **New > Blueprint**, connect GitHub, pick `energy-monitor`.
2. It reads `render.yaml`. When asked for **APP_PASSWORD**, type the password you want for the website.
3. Click **Apply**. After a few minutes you get a link like `https://energy-monitor-xxxx.onrender.com`. Open it: you should see the login page.
4. In Render open the service > **Environment** and copy the value of **DEVICE_KEY**. The ESP32 needs it later.

## 3. Attach your domain (GoDaddy)
1. In Render open the service > **Settings > Custom Domains > Add**. Type `energy.lowkeypeek.com`. Render shows a target such as `energy-monitor-xxxx.onrender.com`.
2. In GoDaddy open **My Products > lowkeypeek.com > DNS > Add New Record**:
   - Type: **CNAME**
   - Name: **energy**
   - Value: the target from Render (without https://)
   - TTL: default
3. Save. Back in Render click **Verify**. It usually takes 10 to 30 minutes, then HTTPS turns on by itself.
4. Open https://energy.lowkeypeek.com and log in.

## 4. The ESP32 sends to your domain
Every reading is an HTTPS POST to `https://energy.lowkeypeek.com/api/hardware/reading` with header `x-device-key: <your DEVICE_KEY>`.
Test it from your Mac before the real board exists:
```
DEVICE_KEY=paste-key-here node tools/virtual-esp32.js https://energy.lowkeypeek.com
```
In ESP32 code use `WiFiClientSecure` (call `setInsecure()` for a first test, then add the root certificate).

## 5. Know the limits of the free plan
- It sleeps after 15 minutes without visitors: the first page load takes about 30 seconds. Open it a few minutes before presenting.
- Saved history is erased on every restart or redeploy. To keep it, add a Render disk (paid) and set `DATA_DIR` to the disk path.
- Demo simulator data keeps running while the page is awake. When the real ESP32 posts, the badge changes to LIVE HARDWARE.

## Settings you can change on the host
| Variable | Meaning |
|---|---|
| APP_PASSWORD | Website password. Leave empty and the site is open to everyone. |
| SESSION_SECRET | Keeps you logged in across restarts. |
| DEVICE_KEY | Secret the ESP32 must send. Leave empty and anyone can post readings. |
| TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID | Phone alerts. |
| DATA_DIR | Folder for saved data. |

Other hosts: Railway and Fly.io can run the included `Dockerfile` the same way.
