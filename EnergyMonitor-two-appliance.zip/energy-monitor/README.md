# EnergyMonitor: two-appliance version (bulb + fan)

Node.js + Express backend, plain HTML/JS frontend, no build step. Works with no hardware
(built-in simulator) and switches to real data the moment an ESP32 starts posting.

## Run it
1. Install Node.js (LTS) from nodejs.org.
2. In this folder: `npm install` (skip if `node_modules` is included), then `npm start`.
3. Open http://localhost:3000

Second terminal, optional: `node tools/virtual-esp32.js` acts like the real ESP32 (posts V, I, P, PF and a raw
waveform every second). Keys: b bulb, 0-3 fan, f friction, s sag, d drop Wi-Fi, q quit.

## Pages
| Page | What it shows |
|---|---|
| Overview | Live power, voltage, kWh, cost, CO2; per-appliance state and health; 10-minute power chart; 1-hour state timeline; alerts; plain-English insights |
| Scope | Voltage and current waveforms, instantaneous power, phasor and power triangle, harmonics. All maths is the same the firmware runs |
| Room | Live picture of the bench: bulb glows by watts, fan spins at detected speed, wires pulse with current. Controls for the simulator |
| Health | Learned normal per state, deviation chart, power-factor chart, health score, data-quality check |
| Insights | Rule-based findings, 7-day forecast with measured backtest error, alert settings, phone alerts |
| What-if | Sliders and toggles for hours, LED swap, fan speed; real UPPCL slab maths; CO2 |
| Hardware | Link status, JSON contract for the ESP32, sensor notes |

**Story mode** (button, top right): a 100-second scripted demo: fan speeds, bearing friction fault with alert, cleaning, voltage sag.

## Data honesty
- Header badge shows the source: LIVE HARDWARE, VIRTUAL ESP32, DEMO SIMULATOR or ESP32 OFFLINE.
- History before the first day of running is **demo-generated** (labelled "seed"). Forecast, month estimate and habit
  insights say so until 7 measured days exist.
- The Scope page says "reconstructed" when no raw samples were posted, and "raw" when the ESP32 sent them.

## ESP32 contract
`POST /api/hardware/reading`, one request per appliance per second:
```json
{"id":"fan","v":229.8,"i":0.261,"p":52.4,"pf":0.88,"f":50.0,"kwh":0.0123,
 "wave":{"cycles":1,"v":[... 128 volts ...],"i":[... 128 amps ...]}}
```
`id` is `bulb` or `fan`. `wave` is optional. Server replies 204, or 400 with the reason. Ranges: V 80-300, I 0-6 A, P 0-1500 W.

## Put it online
See `DEPLOY.md` for the step-by-step guide (Render + GoDaddy subdomain, password login, ESP32 device key).

## Phone alerts (optional)
Set environment variables before `npm start`:
- Telegram: `TELEGRAM_BOT_TOKEN` and `TELEGRAM_CHAT_ID`
- or any webhook: `ALERT_WEBHOOK_URL` (receives `{"text": "..."}`)

Windows example: `set TELEGRAM_BOT_TOKEN=123:abc` then `set TELEGRAM_CHAT_ID=987654` then `npm start`.
This part is written but has not been tested against a live Telegram bot.

## Settings and data
Saved in `server/data/twin.json` (created on first run; delete it to start fresh). Alert limits, quiet hours and the
"rest of building" kWh (which sets the tariff slab) can be changed on the Insights page.

## Files
`server/twin.js` core (state detection, health, alerts) · `server/sim.js` simulator and story · `server/insights.js` insights, forecast, what-if ·
`server/hardware.js` ESP32 ingest · `server/tariff.js` UPPCL LMV-1 FY2026-27 · `public/` pages · `legacy/` the earlier 25-device household version (not served).
