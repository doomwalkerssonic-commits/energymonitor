const fs = require("fs");
const path = require("path");

const FILE = path.join(__dirname, "data", "devices.json");

// 25 devices representative of a normal Indian household, grouped into 5 rooms.
const SEED = [
  // Kitchen
  { id: "k1", name: "Refrigerator", room: "Kitchen", icon: "fridge", ratedWatts: 150, mode: "cyclic", active: true },
  { id: "k2", name: "Microwave oven", room: "Kitchen", icon: "microwave", ratedWatts: 1200, mode: "burst", active: true },
  { id: "k3", name: "Mixer grinder", room: "Kitchen", icon: "blender", ratedWatts: 600, mode: "burst", active: true },
  { id: "k4", name: "Water purifier (RO)", room: "Kitchen", icon: "droplet", ratedWatts: 40, mode: "cyclic", active: true },
  { id: "k5", name: "Kitchen chimney", room: "Kitchen", icon: "fan", ratedWatts: 180, mode: "burst", active: true },
  // Living room
  { id: "l1", name: "LED television", room: "Living Room", icon: "tv", ratedWatts: 120, mode: "evening", active: true },
  { id: "l2", name: "Split AC", room: "Living Room", icon: "ac", ratedWatts: 1500, mode: "afternoon", active: true },
  { id: "l3", name: "Ceiling fan", room: "Living Room", icon: "fan", ratedWatts: 75, mode: "always", active: true },
  { id: "l4", name: "Wi-Fi router", room: "Living Room", icon: "router", ratedWatts: 15, mode: "always", active: true },
  { id: "l5", name: "Set-top box", room: "Living Room", icon: "box", ratedWatts: 20, mode: "evening", active: true },
  // Bedroom
  { id: "b1", name: "Bedroom AC", room: "Bedroom", icon: "ac", ratedWatts: 1500, mode: "night", active: true },
  { id: "b2", name: "Ceiling fan", room: "Bedroom", icon: "fan", ratedWatts: 75, mode: "always", active: true },
  { id: "b3", name: "Bedside lamp", room: "Bedroom", icon: "bulb", ratedWatts: 40, mode: "evening", active: true },
  { id: "b4", name: "Phone & laptop chargers", room: "Bedroom", icon: "plug", ratedWatts: 50, mode: "night", active: true },
  { id: "b5", name: "Study laptop", room: "Bedroom", icon: "laptop", ratedWatts: 65, mode: "burst", active: true },
  // Bathroom
  { id: "w1", name: "Water heater (geyser)", room: "Bathroom", icon: "heater", ratedWatts: 2000, mode: "morning-evening", active: true },
  { id: "w2", name: "Exhaust fan", room: "Bathroom", icon: "fan", ratedWatts: 35, mode: "burst", active: true },
  { id: "w3", name: "Water pump motor", room: "Bathroom", icon: "pump", ratedWatts: 750, mode: "morning-evening", active: true },
  { id: "w4", name: "Hair dryer", room: "Bathroom", icon: "dryer", ratedWatts: 1000, mode: "burst-low", active: true },
  { id: "w5", name: "LED bathroom light", room: "Bathroom", icon: "bulb", ratedWatts: 12, mode: "morning-evening", active: true },
  // Utility
  { id: "u1", name: "Washing machine", room: "Utility", icon: "washer", ratedWatts: 700, mode: "burst", active: true },
  { id: "u2", name: "Electric iron", room: "Utility", icon: "iron", ratedWatts: 1100, mode: "burst-low", active: true },
  { id: "u3", name: "Inverter / UPS (charging)", room: "Utility", icon: "battery", ratedWatts: 200, mode: "always", active: true },
  { id: "u4", name: "Air fryer", room: "Utility", icon: "airfryer", ratedWatts: 1400, mode: "burst-low", active: true },
  { id: "u5", name: "Vacuum cleaner", room: "Utility", icon: "vacuum", ratedWatts: 800, mode: "burst-low", active: true },
];

const ROOMS = ["Kitchen", "Living Room", "Bedroom", "Bathroom", "Utility"];

const ICON_KEYWORDS = [
  [/fridge|refrigerator/i, "fridge"], [/microwave/i, "microwave"], [/mixer|blender|grinder/i, "blender"],
  [/purifier|water filter/i, "droplet"], [/chimney|exhaust|vent/i, "fan"], [/fan/i, "fan"],
  [/\btv\b|television/i, "tv"], [/\bac\b|air condition/i, "ac"], [/router|wifi|wi-fi/i, "router"],
  [/set-top|settop|box/i, "box"], [/lamp|light|bulb/i, "bulb"], [/charger|plug/i, "plug"],
  [/laptop|computer|pc\b/i, "laptop"], [/geyser|water heater|heater/i, "heater"], [/pump|motor/i, "pump"],
  [/dryer/i, "dryer"], [/wash(ing)? machine/i, "washer"], [/iron/i, "iron"],
  [/inverter|ups|battery/i, "battery"], [/fryer|oven|toaster/i, "airfryer"], [/vacuum/i, "vacuum"],
];

function inferIcon(name) {
  for (const [re, icon] of ICON_KEYWORDS) if (re.test(name)) return icon;
  return "plug";
}

function ensureFile() {
  if (!fs.existsSync(FILE)) {
    fs.writeFileSync(FILE, JSON.stringify(SEED, null, 2));
  }
}

function readDevices() {
  ensureFile();
  return JSON.parse(fs.readFileSync(FILE, "utf-8"));
}

function writeDevices(devices) {
  fs.writeFileSync(FILE, JSON.stringify(devices, null, 2));
}

function addDevice({ name, room, ratedWatts }) {
  const devices = readDevices();
  const device = {
    id: "d" + Date.now(),
    name,
    room: ROOMS.includes(room) ? room : "Utility",
    icon: inferIcon(name),
    ratedWatts: Number(ratedWatts) || 50,
    mode: "custom",
    active: true,
  };
  devices.push(device);
  writeDevices(devices);
  return device;
}

function setActive(id, active) {
  const devices = readDevices();
  const device = devices.find((d) => d.id === id);
  if (!device) return null;
  device.active = !!active;
  writeDevices(devices);
  return device;
}

function removeDevice(id) {
  const devices = readDevices().filter((d) => d.id !== id);
  writeDevices(devices);
  return devices;
}

module.exports = { readDevices, writeDevices, addDevice, removeDevice, setActive, ROOMS };
