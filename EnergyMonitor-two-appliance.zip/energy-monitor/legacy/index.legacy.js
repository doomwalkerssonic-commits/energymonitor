const express = require("express");
const path = require("path");
const db = require("./db");
const sim = require("./simulate");
const tariff = require("./tariff");
const hw = require("./hardware");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "..", "public")));

const TIPS = [
  "Shift laundry and dishwashing to the 9am-5pm solar window to cut the ToD surcharge.",
  "A 1-degree higher AC setpoint can cut cooling load by roughly 6%.",
  "Standby electronics still draw power \u2014 switch off at the plug, not just the remote.",
  "Refrigerator coils collect dust over time, making the compressor work harder. Clean them every few months.",
  "Running high-load appliances after 10pm avoids both the evening peak and the solar window \u2014 still cheaper than 6-9pm.",
];

// ---- Devices ----
app.get("/api/devices", (req, res) => {
  const devices = db.readDevices();
  const withPower = devices.map((d) => ({
    ...d, currentWatts: sim.state.devicePower[d.id] ?? 0,
    hardware: hw.CHANNELS[d.id] ? { live: !!hw.fresh(d.id), label: hw.CHANNELS[d.id].label } : null,
  }));
  res.json(withPower);
});

app.post("/api/devices", (req, res) => {
  const { name, room, ratedWatts } = req.body;
  if (!name || !ratedWatts) return res.status(400).json({ error: "name and ratedWatts are required" });
  const device = db.addDevice({ name, room, ratedWatts });
  res.status(201).json(device);
});

app.get("/api/rooms", (req, res) => res.json(db.ROOMS));

app.post("/api/devices/:id/active", (req, res) => {
  const device = db.setActive(req.params.id, req.body.active);
  if (!device) return res.status(404).json({ error: "device not found" });
  res.json(device);
});

app.delete("/api/devices/:id", (req, res) => {
  const devices = db.removeDevice(req.params.id);
  res.json(devices);
});

// ---- Hardware (ESP32 + PZEM) ----
app.post("/api/hardware/reading", (req, res) => {
  const err = hw.validate(req.body);
  if (err) return res.status(400).json({ error: err });
  hw.ingest(req.body);
  res.sendStatus(204);
});
app.get("/api/hardware", (req, res) => res.json(hw.snapshot()));

// ---- Live readings ----
app.get("/api/live", (req, res) => {
  res.json({
    day: sim.state.day, hour: sim.state.hour, minute: sim.state.minute,
    voltage: Number(sim.state.voltage.toFixed(1)),
    current: Number(sim.state.current.toFixed(2)),
    power: Number(sim.state.power.toFixed(2)),
    energyToday: Number(sim.state.energyToday.toFixed(2)),
    fault: sim.state.faultActive,
  });
});

app.get("/api/readings", (req, res) => res.json(sim.state.readings));
app.get("/api/hourly", (req, res) => res.json(sim.state.hourlyEnergy));
app.get("/api/alerts", (req, res) => res.json(sim.state.alerts));
app.post("/api/alerts/trigger-fault", (req, res) => { sim.triggerFault(); res.json({ ok: true }); });

// ---- Forecast: simple moving-average next-day prediction ----
app.get("/api/forecast", (req, res) => {
  const hourly = sim.state.hourlyEnergy;
  const consumedSoFar = hourly.slice(0, sim.state.hour + 1).reduce((a, b) => a + b, 0);
  const hoursElapsed = sim.state.hour + 1;
  const avgPerHour = hoursElapsed > 0 ? consumedSoFar / hoursElapsed : 0;
  const projectedToday = avgPerHour * 24;
  res.json({
    projectedTodayKwh: Number(projectedToday.toFixed(2)),
    avgPerHourKwh: Number(avgPerHour.toFixed(3)),
    basis: `Moving average of ${hoursElapsed} simulated hour(s) so far`,
  });
});

// ---- Billing ----
app.get("/api/billing", (req, res) => {
  const bill = tariff.computeBill(sim.state.billingBuckets);
  res.json({
    ...bill,
    slabs: tariff.SLABS.map(s => ({ upto: s.upto === Infinity ? null : s.upto, rate: s.rate })),
    fixedChargePerKw: tariff.FIXED_CHARGE_PER_KW,
    sanctionedLoadKw: tariff.SANCTIONED_LOAD_KW,
    todAdjustmentPct: tariff.TOD_ADJUSTMENT * 100,
    peakHours: [...tariff.PEAK_HOURS].sort((a,b)=>a-b),
    solarHours: [...tariff.SOLAR_HOURS].sort((a,b)=>a-b),
  });
});

app.get("/api/billing/export.csv", (req, res) => {
  const hourly = sim.state.hourlyEnergy;
  let csv = "hour,energy_kwh,tod_bucket\n";
  hourly.forEach((v, h) => { csv += `${h},${v.toFixed(3)},${tariff.classifyHour(h)}\n`; });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=consumption_history.csv");
  res.send(csv);
});

// ---- Tips ----
app.get("/api/tip", (req, res) => {
  const idx = Math.floor(Date.now() / 20000) % TIPS.length;
  res.json({ tip: TIPS[idx] });
});

sim.start();

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`EnergyMonitor server running \u2192 http://localhost:${PORT}`);
});
