function rupee(n) { return '\u20b9' + Number(n).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }

async function loadBilling() {
  const b = await getJSON('/api/billing');
  document.getElementById('b-units').textContent = b.totalUnits.toFixed(2);
  document.getElementById('b-rate').textContent = b.blendedRate.toFixed(2);
  document.getElementById('b-total').textContent = b.total.toFixed(0);

  document.getElementById('row-base').textContent = rupee(b.baseEnergyCharge);
  document.getElementById('row-peak').textContent = '+' + rupee(b.peakSurcharge);
  document.getElementById('row-solar').textContent = '\u2212' + rupee(b.solarRebate);
  document.getElementById('row-fixed').textContent = rupee(b.fixedCharge);
  document.getElementById('row-trueup').textContent = rupee(b.trueUp);
  document.getElementById('row-duty').textContent = rupee(b.duty);
  document.getElementById('row-rent').textContent = rupee(b.meterRent);
  document.getElementById('row-total').textContent = rupee(b.total);

  document.getElementById('peak-hours').textContent = b.peakHours.map(h => h + ':00').join(', ');
  document.getElementById('solar-hours').textContent = b.solarHours[0] + ':00\u2013' + (b.solarHours[b.solarHours.length-1]+1) + ':00';

  const slabTable = document.getElementById('slab-table');
  let lower = 0;
  const rows = b.slabs.map(s => {
    const label = s.upto ? `${lower + 1}\u2013${s.upto} units` : `Above ${lower} units`;
    lower = s.upto;
    return `<tr><td>${label}</td><td style="text-align:right" class="mono">\u20b9${s.rate.toFixed(2)}/unit</td></tr>`;
  }).join('');
  slabTable.innerHTML = '<tr><th>Slab</th><th style="text-align:right">Rate</th></tr>' + rows;
}

loadBilling();
setInterval(loadBilling, 3000);
