let liveChart = null, barChart = null;
const liveLabels = [], voltageData = [], currentData = [];

function initCharts() {
  if (typeof Chart === 'undefined') {
    console.warn('Chart.js did not load \u2014 charts will stay blank, but the rest of the dashboard will keep working.');
    return;
  }
  try {
    liveChart = new Chart(document.getElementById('liveChart'), {
      type: 'line',
      data: { labels: liveLabels, datasets: [
        { label: 'Voltage (V)', data: voltageData, borderColor: COLORS.teal, backgroundColor: 'transparent', yAxisID: 'y', tension: .3, pointRadius: 0, borderWidth: 2 },
        { label: 'Current (A)', data: currentData, borderColor: COLORS.amber, backgroundColor: 'transparent', yAxisID: 'y1', tension: .3, pointRadius: 0, borderWidth: 2 }
      ]},
      options: {
        responsive: true, maintainAspectRatio: false, animation: false, interaction: { intersect: false, mode: 'index' },
        plugins: { legend: { labels: { color: COLORS.muted, boxWidth: 12, font: { size: 11 } } } },
        scales: {
          x: { ticks: { color: COLORS.muted, maxTicksLimit: 8, font: { size: 10 } }, grid: { color: COLORS.grid } },
          y: { position: 'left', ticks: { color: COLORS.teal, font: { size: 10 } }, grid: { color: COLORS.grid } },
          y1: { position: 'right', ticks: { color: COLORS.amber, font: { size: 10 } }, grid: { drawOnChartArea: false } }
        }
      }
    });
    barChart = new Chart(document.getElementById('barChart'), {
      type: 'bar',
      data: { labels: Array.from({length:24},(_,i)=>i), datasets: [{ label: 'kWh', data: new Array(24).fill(0), backgroundColor: COLORS.teal, borderRadius: 3 }] },
      options: {
        responsive: true, maintainAspectRatio: false, animation: false, plugins: { legend: { display: false } },
        scales: {
          x: { ticks: { color: COLORS.muted, font: { size: 10 } }, grid: { display: false } },
          y: { ticks: { color: COLORS.muted, font: { size: 10 } }, grid: { color: COLORS.grid } }
        }
      }
    });
  } catch (err) {
    console.warn('Chart initialization failed, continuing without charts:', err);
    liveChart = null; barChart = null;
  }
}
initCharts();

async function refreshLive() {
  try {
    const d = await getJSON('/api/live');
    document.getElementById('v-voltage').textContent = d.voltage.toFixed(1);
    document.getElementById('v-current').textContent = d.current.toFixed(2);
    document.getElementById('v-power').textContent = d.power.toFixed(2);
    document.getElementById('v-energy').textContent = d.energyToday.toFixed(2);
    document.getElementById('clock').textContent = `Day ${d.day} \u00b7 ` + String(d.hour).padStart(2,'0') + ':' + String(d.minute).padStart(2,'0');
    const badge = document.getElementById('status-badge'), text = document.getElementById('status-text');
    badge.className = 'status' + (d.fault ? ' fault' : ' ok');
    text.textContent = d.fault ? 'Fault detected' : 'Normal';
  } catch (err) { console.warn('refreshLive failed:', err); }
}

async function refreshReadings() {
  try {
    const readings = await getJSON('/api/readings');
    liveLabels.length = 0; voltageData.length = 0; currentData.length = 0;
    readings.forEach(r => { liveLabels.push(''); voltageData.push(r.voltage); currentData.push(r.current); });
    if (liveChart) liveChart.update('none');
  } catch (err) { console.warn('refreshReadings failed:', err); }
}

async function refreshHourly() {
  try {
    const hourly = await getJSON('/api/hourly');
    if (barChart) { barChart.data.datasets[0].data = hourly; barChart.update('none'); }
  } catch (err) { console.warn('refreshHourly failed:', err); }
}

async function refreshAlerts() {
  try {
    const alerts = await getJSON('/api/alerts');
    const log = document.getElementById('alert-log');
    if (alerts.length === 0) { log.innerHTML = '<div class="alert-empty">No alerts yet \u2014 readings are within normal range.</div>'; return; }
    log.innerHTML = alerts.map(a => `<div class="alert ${a.type}"><div class="a-title">${a.label}</div><div class="a-meta mono">${a.time} \u00b7 ${a.value}</div></div>`).join('');
  } catch (err) { console.warn('refreshAlerts failed:', err); }
}

async function refreshTip() {
  try {
    const { tip } = await getJSON('/api/tip');
    document.getElementById('tip-text').textContent = tip;
  } catch (err) { console.warn('refreshTip failed:', err); }
}

document.getElementById('btn-fault').addEventListener('click', async () => {
  await fetch('/api/alerts/trigger-fault', { method: 'POST' });
});

function refreshAll() { refreshLive(); refreshReadings(); refreshHourly(); refreshAlerts(); }
refreshAll();
refreshTip();
setInterval(refreshAll, 1500);
setInterval(refreshTip, 20000);
