const ACCENT_BY_ROOM = { "Kitchen": "copper", "Living Room": "teal", "Bedroom": "blue", "Bathroom": "amber", "Utility": "green" };
const ROOM_ORDER = ["Kitchen", "Living Room", "Bedroom", "Bathroom", "Utility"];

async function loadDevices() {
  const devices = await getJSON('/api/devices');
  const list = document.getElementById('device-list');
  if (devices.length === 0) { list.innerHTML = '<div class="alert-empty">No devices yet.</div>'; return; }

  const byRoom = {};
  devices.forEach(d => { (byRoom[d.room] = byRoom[d.room] || []).push(d); });

  list.innerHTML = ROOM_ORDER.filter(r => byRoom[r]).map(room => {
    const accent = ACCENT_BY_ROOM[room] || 'teal';
    const rows = byRoom[room].map(d => {
      const active = d.active !== false;
      return `
      <div class="device-row ${active ? '' : 'inactive'}">
        <div style="display:flex; align-items:center; gap:12px;">
          <div class="icon-wrap accent-${accent}">${iconSvg(d.icon, 18)}</div>
          <div>
            <div class="device-name">${d.name}${d.hardware ? ` <span class="pill" style="margin-left:6px;${d.hardware.live ? 'color:var(--green);border-color:var(--green)' : ''}">${d.hardware.live ? 'LIVE HARDWARE' : 'hardware offline'}</span>` : ''}</div>
            <div class="device-meta">rated ${d.ratedWatts} W</div>
          </div>
        </div>
        <div style="display:flex; align-items:center; gap:14px;">
          <div style="text-align:right;">
            <div class="device-watts">${d.currentWatts} W</div>
            <div class="device-meta">right now</div>
          </div>
          <div class="toggle-pair" data-id="${d.id}">
            <button class="toggle-btn on ${active ? 'selected' : ''}" data-active="true">Active</button>
            <button class="toggle-btn off ${active ? '' : 'selected'}" data-active="false">Inactive</button>
          </div>
        </div>
      </div>
    `;
    }).join('');
    return `<div style="margin-bottom:18px;"><div class="pill" style="margin-bottom:8px;">${room}</div>${rows}</div>`;
  }).join('');

  list.querySelectorAll('.toggle-pair').forEach(pair => {
    pair.querySelectorAll('.toggle-btn').forEach(btn => {
      btn.addEventListener('click', async () => {
        await fetch('/api/devices/' + pair.dataset.id + '/active', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ active: btn.dataset.active === 'true' })
        });
        loadDevices();
      });
    });
  });
}

document.getElementById('btn-add').addEventListener('click', async () => {
  const name = document.getElementById('f-name').value.trim();
  const room = document.getElementById('f-room').value;
  const ratedWatts = document.getElementById('f-watts').value;
  const errorEl = document.getElementById('form-error');

  if (!name || !ratedWatts || Number(ratedWatts) <= 0) {
    errorEl.textContent = 'Enter a device name and a rated wattage greater than 0.';
    errorEl.style.display = 'block';
    return;
  }
  errorEl.style.display = 'none';

  await fetch('/api/devices', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, room, ratedWatts })
  });
  document.getElementById('f-name').value = '';
  document.getElementById('f-watts').value = '';
  loadDevices();
});

loadDevices();
setInterval(loadDevices, 2000);
