const $ = (id) => document.getElementById(id);
const f = (x, d) => (x == null ? '--' : Number(x).toFixed(d));

function setFlow(pathEl, on, current) {
  pathEl.classList.toggle('flow', on);
  pathEl.classList.toggle('off', !on);
  if (on) pathEl.style.animationDuration = Math.max(0.25, 1.2 - current * 2).toFixed(2) + 's';
}

async function refresh() {
  let d;
  try { d = await getJSON('/api/hardware'); } catch (e) { return; }
  const b = d.channels.b3, n = d.channels.l3;
  const anyLive = b.live || n.live;

  const pill = $('conn');
  pill.textContent = anyLive ? 'ESP32 connected' : (d.source ? 'ESP32 offline (no data for 5 s)' : 'Waiting for ESP32');
  pill.className = 'live-pill ' + (anyLive ? 'on' : 'off');
  $('src').textContent = d.source ? 'source: ' + d.source : '';
  $('esp-led').setAttribute('fill', anyLive ? '#5CC98A' : '#5F6875');

  $('p1a').textContent = b.live ? `${f(b.v,1)} V   ${f(b.i,3)} A` : '-- V   -- A';
  $('p1b').textContent = b.live ? `${f(b.p,1)} W   PF ${f(b.pf,2)}   ${f(b.f,1)} Hz` : 'offline';
  $('p2a').textContent = n.live ? `${f(n.v,1)} V   ${f(n.i,3)} A` : '-- V   -- A';
  $('p2b').textContent = n.live ? `${f(n.p,1)} W   PF ${f(n.pf,2)}   ${f(n.f,1)} Hz` : 'offline';

  // bulb brightness and fan speed follow real power
  const bp = b.live ? b.p : 0, np = n.live ? n.p : 0;
  $('bulb-glow').setAttribute('opacity', Math.min(0.9, bp / 65).toFixed(2));
  $('bulb').setAttribute('fill', bp > 5 ? '#F2A93B' : '#20262F');
  const blades = $('fan-blades');
  if (np > 5) {
    blades.style.animationDuration = Math.max(0.15, 1.6 - np / 50).toFixed(2) + 's';
    blades.style.animationPlayState = 'running';
  } else blades.style.animationPlayState = 'paused';

  setFlow($('wire-b3'), bp > 5, b.i || 0);
  setFlow($('wire-l3'), np > 5, n.i || 0);
  setFlow($('ser1'), b.live, 0);
  setFlow($('ser2'), n.live, 0);
  setFlow($('wifi'), anyLive, 0);
  setFlow($('to-dash'), anyLive, 0);

  const srv = (b.serverKwh || 0) + (n.serverKwh || 0);
  const mod = (b.moduleKwh == null && n.moduleKwh == null) ? null : (b.moduleKwh || 0) + (n.moduleKwh || 0);
  $('e-srv').textContent = `server  ${srv.toFixed(5)} kWh`;
  $('e-mod').textContent = `modules ${mod == null ? '--' : mod.toFixed(5)} kWh`;
  $('dash-w').textContent = `${Math.round(bp + np)} W`;

  const rows = [
    ['Status', b.live ? 'live' : 'offline', n.live ? 'live' : 'offline'],
    ['Voltage', b.live ? f(b.v,1) + ' V' : '--', n.live ? f(n.v,1) + ' V' : '--'],
    ['Current', b.live ? f(b.i,3) + ' A' : '--', n.live ? f(n.i,3) + ' A' : '--'],
    ['Real power', b.live ? f(b.p,1) + ' W' : '--', n.live ? f(n.p,1) + ' W' : '--'],
    ['Power factor', b.live ? f(b.pf,2) : '--', n.live ? f(n.pf,2) : '--'],
    ['Frequency', b.live ? f(b.f,1) + ' Hz' : '--', n.live ? f(n.f,1) + ' Hz' : '--'],
    ['Energy (server)', f(b.serverKwh,5) + ' kWh', f(n.serverKwh,5) + ' kWh'],
    ['Energy (module)', b.moduleKwh == null ? '--' : f(b.moduleKwh,5) + ' kWh', n.moduleKwh == null ? '--' : f(n.moduleKwh,5) + ' kWh'],
    ['Meter', b.meter + ' ' + b.address, n.meter + ' ' + n.address],
  ];
  $('tbl').innerHTML = rows.map(r => `<tr><td>${r[0]}</td><td class="mono">${r[1]}</td><td class="mono">${r[2]}</td></tr>`).join('');
}
refresh();
setInterval(refresh, 1000);
