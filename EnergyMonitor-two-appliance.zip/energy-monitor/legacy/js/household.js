const ROOM_META = {
  "Kitchen": { accent: "copper" },
  "Living Room": { accent: "teal" },
  "Bedroom": { accent: "blue" },
  "Bathroom": { accent: "amber" },
  "Utility": { accent: "green" },
};
const ROOM_ORDER = ["Kitchen", "Living Room", "Bedroom", "Bathroom", "Utility"];

async function refreshHousehold() {
  const [devices, live] = await Promise.all([getJSON('/api/devices'), getJSON('/api/live')]);

  document.getElementById('total-clock').textContent = `Day ${live.day} \u00b7 ` + String(live.hour).padStart(2,'0') + ':' + String(live.minute).padStart(2,'0');
  const totalW = devices.reduce((sum, d) => sum + (d.currentWatts || 0), 0);
  document.getElementById('total-watts').textContent = totalW.toLocaleString('en-IN') + ' W';

  const byRoom = {};
  devices.forEach(d => { (byRoom[d.room] = byRoom[d.room] || []).push(d); });

  const grid = document.getElementById('room-grid');
  grid.innerHTML = ROOM_ORDER.filter(r => byRoom[r]).map(room => {
    const list = byRoom[room];
    const subtotal = list.reduce((s, d) => s + (d.currentWatts || 0), 0);
    const accent = (ROOM_META[room] || { accent: "teal" }).accent;
    const rows = list.map(d => {
      const active = d.active !== false;
      return `
      <div class="device-row ${active ? '' : 'inactive'}">
        <div style="display:flex; align-items:center; gap:12px;">
          <div class="icon-wrap accent-${accent}">${iconSvg(d.icon, 18)}</div>
          <div>
            <div class="device-name">${d.name}</div>
            <div class="device-meta">rated ${d.ratedWatts} W${active ? '' : ' \u00b7 inactive'}</div>
          </div>
        </div>
        <div class="device-watts">${d.currentWatts} W</div>
      </div>
    `;
    }).join('');
    return `
      <div class="room-card">
        <div class="room-card-header">
          <div style="display:flex; align-items:center; gap:10px;">
            <div class="icon-wrap accent-${accent} lg">${iconSvg(roomIcon(room), 22)}</div>
            <h2>${room}</h2>
          </div>
          <div class="room-subtotal mono accent-text-${accent}">${subtotal.toLocaleString('en-IN')} W</div>
        </div>
        <div>${rows}</div>
      </div>
    `;
  }).join('');
}

function roomIcon(room) {
  return { "Kitchen": "blender", "Living Room": "tv", "Bedroom": "bulb", "Bathroom": "droplet", "Utility": "washer" }[room] || "plug";
}

refreshHousehold();
setInterval(refreshHousehold, 2000);
