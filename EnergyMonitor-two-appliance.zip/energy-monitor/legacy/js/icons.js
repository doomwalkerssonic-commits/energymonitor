const ICON_PATHS = {
  fridge: '<rect x="6" y="2" width="12" height="20" rx="1.5"/><line x1="6" y1="9" x2="18" y2="9"/><line x1="15" y1="4.5" x2="15" y2="6.5"/><line x1="15" y1="12" x2="15" y2="14"/>',
  microwave: '<rect x="2" y="6" width="20" height="13" rx="1.5"/><rect x="4.5" y="8.5" width="11" height="8" rx="0.5"/><circle cx="19" cy="10" r="0.9" fill="currentColor" stroke="none"/><line x1="17.5" y1="13" x2="20.5" y2="13"/><line x1="17.5" y1="15.5" x2="20.5" y2="15.5"/>',
  blender: '<path d="M9 3h6l1.5 12h-9z"/><rect x="7" y="15" width="10" height="6" rx="1"/>',
  droplet: '<path d="M12 2c4 5 7 9 7 13a7 7 0 0 1-14 0c0-4 3-8 7-13z"/>',
  fan: '<circle cx="12" cy="12" r="1.6" fill="currentColor" stroke="none"/><ellipse cx="12" cy="6" rx="2.2" ry="4.5"/><ellipse cx="12" cy="6" rx="2.2" ry="4.5" transform="rotate(120 12 12)"/><ellipse cx="12" cy="6" rx="2.2" ry="4.5" transform="rotate(240 12 12)"/>',
  tv: '<rect x="2.5" y="4" width="19" height="13" rx="1.5"/><line x1="8" y1="20.5" x2="16" y2="20.5"/><line x1="12" y1="17" x2="12" y2="20.5"/>',
  ac: '<rect x="2" y="6" width="20" height="7" rx="2"/><line x1="5" y1="9.5" x2="19" y2="9.5"/><path d="M8 16l1.5 2M12 16l1.5 2M16 16l1.5 2"/>',
  router: '<rect x="3" y="14" width="18" height="6" rx="1.5"/><line x1="8" y1="14" x2="6" y2="5"/><line x1="16" y1="14" x2="18" y2="5"/><circle cx="7" cy="17" r="0.8" fill="currentColor" stroke="none"/><circle cx="10.5" cy="17" r="0.8" fill="currentColor" stroke="none"/>',
  box: '<rect x="3" y="8" width="18" height="8" rx="1.5"/><circle cx="18" cy="12" r="1" fill="currentColor" stroke="none"/>',
  bulb: '<circle cx="12" cy="9" r="6"/><line x1="9.5" y1="19" x2="14.5" y2="19"/><line x1="10" y1="21" x2="14" y2="21"/><line x1="12" y1="15" x2="12" y2="19"/>',
  plug: '<rect x="7" y="9" width="10" height="7" rx="1.5"/><line x1="10" y1="9" x2="10" y2="5"/><line x1="14" y1="9" x2="14" y2="5"/><path d="M7 16c0 3-3 3-3 6"/>',
  laptop: '<rect x="5" y="4" width="14" height="10" rx="1"/><path d="M2 18h20l-2 3H4z"/>',
  heater: '<rect x="7" y="3" width="10" height="17" rx="4"/><path d="M10 8c1 1 1 2 0 3s-1 2 0 3"/><path d="M14 8c1 1 1 2 0 3s-1 2 0 3"/>',
  pump: '<circle cx="12" cy="10" r="5"/><circle cx="12" cy="10" r="1.5" fill="currentColor" stroke="none"/><line x1="12" y1="15" x2="12" y2="20"/><line x1="8" y1="20" x2="16" y2="20"/>',
  dryer: '<path d="M3 8l8-3c3 0 6 2 8 3v4c-2 1-5 3-8 3l-8-3z"/><line x1="3" y1="8" x2="3" y2="12"/>',
  washer: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="12" cy="14" r="5.5"/><circle cx="12" cy="14" r="2.2"/><circle cx="6.5" cy="6" r="0.8" fill="currentColor" stroke="none"/><circle cx="9" cy="6" r="0.8" fill="currentColor" stroke="none"/>',
  iron: '<path d="M3 17c0-5 4-10 11-10 4 0 7 2 7 5s-3 5-8 5z"/><path d="M9 7c1-2 3-3 5-3"/>',
  battery: '<rect x="3" y="7" width="16" height="10" rx="1.5"/><rect x="19" y="10" width="2" height="4" fill="currentColor" stroke="none"/><line x1="7" y1="10" x2="7" y2="14"/><line x1="11" y1="10" x2="11" y2="14"/>',
  airfryer: '<rect x="5" y="6" width="14" height="14" rx="3"/><rect x="9" y="2" width="6" height="4" rx="1.5"/><circle cx="12" cy="13" r="3"/>',
  vacuum: '<circle cx="8" cy="14" r="5"/><path d="M13 12c3-1 6 0 7-3"/><line x1="8" y1="19" x2="8" y2="22"/>',
};

function iconSvg(name, size) {
  const inner = ICON_PATHS[name] || ICON_PATHS.plug;
  size = size || 20;
  return `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">${inner}</svg>`;
}
