const db = require("./db");
const tariff = require("./tariff");
const hw = require("./hardware");

const state = {
  day: 1,
  hour: 6,
  minute: 0,
  tickMinutes: 12,
  voltage: 230,
  current: 1.2,
  power: 0.28,
  energyToday: 0,
  hourlyEnergy: new Array(24).fill(0),
  billingBuckets: { normal: 0, peak: 0, solar: 0 },
  deviceCounters: {},
  deviceOn: {},
  devicePower: {},
  forcedFaultTicks: 0,
  faultActive: false,
  readings: [],   // ring buffer: {t, voltage, current}
  alerts: [],     // {id, type, label, value, time}
};

const MAX_READINGS = 90;
const MAX_ALERTS = 12;
const OVER_I = 26.0, UNDER_V = 212, OVER_V = 248;

function deviceWattage(device) {
  const id = device.id;
  state.deviceCounters[id] = (state.deviceCounters[id] || 0) + 1;
  const c = state.deviceCounters[id];
  const h = state.hour;

  if (device.mode === "cyclic") {
    if (c % 4 === 0) state.deviceOn[id] = !state.deviceOn[id];
    if (state.deviceOn[id] === undefined) state.deviceOn[id] = true;
    return state.deviceOn[id] ? device.ratedWatts : 0;
  }
  if (device.mode === "evening") {
    const on = (h >= 5 && h <= 7) || (h >= 18 && h <= 23);
    return on ? device.ratedWatts : 0;
  }
  if (device.mode === "afternoon") {
    return (h >= 13 && h <= 17) ? device.ratedWatts : 0;
  }
  if (device.mode === "night") {
    const on = h >= 22 || h <= 6;
    return on ? device.ratedWatts : 0;
  }
  if (device.mode === "morning-evening") {
    const on = (h >= 6 && h <= 9) || (h >= 18 && h <= 21);
    if (!on) return 0;
    // brief burst-like use within the window, not the full window continuously
    return Math.random() < 0.35 ? device.ratedWatts : device.ratedWatts * 0.05;
  }
  if (device.mode === "always") {
    return device.ratedWatts;
  }
  if (device.mode === "burst") {
    return Math.random() < 0.10 ? device.ratedWatts : 0;
  }
  if (device.mode === "burst-low") {
    return Math.random() < 0.04 ? device.ratedWatts : 0;
  }
  // custom user-added device: simple duty cycle, ~65% on
  if (c % 3 === 0) state.deviceOn[id] = !state.deviceOn[id];
  if (state.deviceOn[id] === undefined) state.deviceOn[id] = true;
  return state.deviceOn[id] ? device.ratedWatts : device.ratedWatts * 0.1;
}

function tick() {
  state.minute += state.tickMinutes;
  if (state.minute >= 60) { state.minute -= 60; state.hour++; }
  if (state.hour >= 24) {
    state.hour = 0; state.day++;
    state.hourlyEnergy.fill(0);
    state.energyToday = 0;
    state.billingBuckets = { normal: 0, peak: 0, solar: 0 };
  }

  const devices = db.readDevices();
  let totalW = 0;
  const devicePower = {};
  for (const d of devices) {
    if (d.active === false) { devicePower[d.id] = 0; continue; }
    if (hw.CHANNELS[d.id]) {
      // fed by hardware: use the latest real reading, or 0 W when offline
      const r = hw.fresh(d.id);
      if (r) { devicePower[d.id] = Math.round(r.p); totalW += devicePower[d.id]; continue; }
      if (hw.snapshot().source) { devicePower[d.id] = 0; continue; }  // hardware was connected, now offline
    }
    const w = deviceWattage(d) + (Math.random() - 0.5) * 3;
    devicePower[d.id] = Math.max(0, Math.round(w));
    totalW += devicePower[d.id];
  }
  state.devicePower = devicePower;

  let voltage = 230 + 3 * Math.sin(Date.now() / 4000) + (Math.random() - 0.5) * 3;
  const inFault = state.forcedFaultTicks > 0 || Math.random() < 0.012;
  if (state.forcedFaultTicks > 0) state.forcedFaultTicks--;

  let powerW = totalW + (Math.random() - 0.5) * 15;
  if (inFault) {
    powerW += 6500 + Math.random() * 1500;
    voltage -= 12 + Math.random() * 8;
  }
  const pf = 0.92;
  const current = powerW / (voltage * pf);

  state.voltage = voltage; state.current = current; state.power = powerW / 1000;

  const dtHours = state.tickMinutes / 60;
  const kwh = (powerW / 1000) * dtHours;
  state.energyToday += kwh;
  state.hourlyEnergy[state.hour] += kwh;

  const bucket = tariff.classifyHour(state.hour);
  state.billingBuckets[bucket] += kwh;

  state.readings.push({ t: Date.now(), voltage: Number(voltage.toFixed(1)), current: Number(current.toFixed(2)) });
  if (state.readings.length > MAX_READINGS) state.readings.shift();

  evaluateAlerts(voltage, current);
}

function evaluateAlerts(voltage, current) {
  const isFault = current > OVER_I || voltage < UNDER_V || voltage > OVER_V;
  if (isFault && !state.faultActive) {
    state.faultActive = true;
    const type = current > OVER_I ? "overcurrent" : (voltage < UNDER_V ? "undervoltage" : "overvoltage");
    const label = type === "overcurrent" ? "Overcurrent" : (type === "undervoltage" ? "Undervoltage" : "Overvoltage");
    const value = type === "overcurrent" ? current.toFixed(1) + " A" : voltage.toFixed(0) + " V";
    pushAlert(type, label, value);
  } else if (!isFault && state.faultActive) {
    state.faultActive = false;
    pushAlert("restored", "Restored", "normal range");
  }
}

function pushAlert(type, label, value) {
  const time = `Day ${state.day} \u00b7 ` + String(state.hour).padStart(2, "0") + ":" + String(state.minute).padStart(2, "0");
  state.alerts.unshift({ id: Date.now(), type, label, value, time });
  if (state.alerts.length > MAX_ALERTS) state.alerts.pop();
}

function triggerFault() { state.forcedFaultTicks = 4; }

function start() {
  setInterval(tick, 1000);
  for (let i = 0; i < 15; i++) tick(); // seed so the UI isn't empty on first load
}

module.exports = { state, start, triggerFault, tariffBucketOf: tariff.classifyHour };
