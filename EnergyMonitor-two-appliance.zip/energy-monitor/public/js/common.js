async function getJSON(url, opts) {
  const res = await fetch(url, opts);
  if (!res.ok) { let m = "Request failed: " + url; try { m = (await res.json()).error || m; } catch (e) {} throw new Error(m); }
  return res.json();
}
function post(url, body) {
  return getJSON(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
}
const $ = (id) => document.getElementById(id);
const fx = (x, d) => (x == null || !isFinite(x) ? "--" : Number(x).toFixed(d));
const COLORS = { teal: "#4FD1C5", amber: "#F2A93B", copper: "#E07B3F", red: "#EF5B5B", green: "#5CC98A", blue: "#8FA3FF", grid: "#27303B", muted: "#8E99A8" };
function rs(x) { return "Rs " + (Math.abs(x) >= 100 ? x.toFixed(0) : x.toFixed(2)); }
function clock(t) { return new Date(t).toLocaleTimeString("en-GB", { hour: "2-digit", minute: "2-digit", second: "2-digit" }); }
function esc(s) { return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c])); }
if (window.Chart) { Chart.defaults.color = COLORS.muted; Chart.defaults.font.family = "'Inter',system-ui,sans-serif"; Chart.defaults.borderColor = COLORS.grid; }
