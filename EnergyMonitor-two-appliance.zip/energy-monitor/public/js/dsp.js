// The same maths the ESP32 firmware will run, written for the browser.
// Input: arrays of instantaneous volts and amps covering a whole number of mains cycles.
function analyze(v, i, cycles) {
  const N = v.length;
  let mv = 0, mi = 0;
  for (let k = 0; k < N; k++) { mv += v[k]; mi += i[k]; }
  mv /= N; mi /= N;                                  // remove DC offset (sensor sits at mid-rail)
  let sv = 0, si = 0, sp = 0, pkV = 0, pkI = 0;
  const vv = new Array(N), ii = new Array(N), pw = new Array(N);
  for (let k = 0; k < N; k++) {
    const a = v[k] - mv, b = i[k] - mi;
    vv[k] = a; ii[k] = b; pw[k] = a * b;
    sv += a * a; si += b * b; sp += a * b;
    pkV = Math.max(pkV, Math.abs(a)); pkI = Math.max(pkI, Math.abs(b));
  }
  const vrms = Math.sqrt(sv / N), irms = Math.sqrt(si / N), p = sp / N;
  const s = vrms * irms, q = Math.sqrt(Math.max(0, s * s - p * p));
  const pf = s > 0.0001 ? Math.min(1, Math.abs(p) / s) : 0;

  // harmonics by DFT; fundamental sits at bin = cycles
  function harm(x, h) {
    const kk = h * cycles; let re = 0, im = 0;
    for (let n = 0; n < N; n++) { const th = (2 * Math.PI * kk * n) / N; re += x[n] * Math.sin(th); im += x[n] * Math.cos(th); }
    return { amp: (2 / N) * Math.hypot(re, im), ph: Math.atan2(im, re) };
  }
  const hi = [], hv = [];
  for (let h = 1; h <= 15; h++) { hi.push(harm(ii, h)); hv.push(harm(vv, h)); }
  const thd = (hs) => { let s2 = 0; for (let h = 1; h < hs.length; h++) s2 += hs[h].amp * hs[h].amp; return hs[0].amp > 1e-6 ? Math.sqrt(s2) / hs[0].amp : 0; };
  let phi = (hv[0].ph - hi[0].ph) * 180 / Math.PI;     // positive = current lags voltage
  while (phi > 180) phi -= 360; while (phi < -180) phi += 360;
  return {
    vrms, irms, p, s, q, pf, phi, vv, ii, pw,
    thdI: thd(hi) * 100, thdV: thd(hv) * 100,
    harmonicsI: hi.map((x) => x.amp / Math.SQRT2), crestI: irms > 0.0001 ? pkI / irms : 0, crestV: vrms > 0 ? pkV / vrms : 0,
    pkV, pkI,
  };
}
