const STATUS_COL = { healthy: "#5CC98A", watch: "#F2A93B", check: "#EF5B5B", idle: "#5C6776", offline: "#5C6776" };
let devChart = null, pfChart = null;

function ring(score, status) {
  const r = 38, C = 2 * Math.PI * r, v = score == null ? 0 : score / 100;
  return `<svg width="104" height="104" viewBox="0 0 104 104"><circle cx="52" cy="52" r="${r}" fill="none" stroke="#27303B" stroke-width="9"/>
    <circle cx="52" cy="52" r="${r}" fill="none" stroke="${STATUS_COL[status]}" stroke-width="9" stroke-linecap="round" stroke-dasharray="${C * v} ${C}" transform="rotate(-90 52 52)"/>
    <text x="52" y="58" text-anchor="middle" font-family="JetBrains Mono,monospace" font-size="24" font-weight="700" fill="#E8EBEF">${score == null ? "--" : score}</text></svg>`;
}

function card(a, base) {
  const rt = a.runtime;
  const mins = (x) => (x / 60).toFixed(0);
  const states = Object.keys(base[a.id]);
  const rows = states.map((s) => {
    const b = base[a.id][s];
    return `<tr><td>${s === "med" ? "MEDIUM" : s.toUpperCase()}</td><td class="mono">${b.w.toFixed(1)} W</td><td class="mono">${b.pf.toFixed(2)}</td><td class="mono">${b.n >= 120 ? "trusted" : "learning " + b.n + "/120 s"}</td></tr>`;
  }).join("");
  const run = a.id === "bulb" ? `${mins(rt.on)} min` : `${mins(rt.low + rt.med + rt.high)} min`;
  return `<div class="panel"><h2>${a.label}</h2>
    <div class="hc">${ring(a.health.score, a.health.status)}<div><div class="st" style="color:${STATUS_COL[a.health.status]}">${a.health.status}</div>
      <ul>${a.health.reasons.map((x) => `<li>${esc(x)}</li>`).join("")}</ul></div></div>
    <div class="mini"><div><b>${run}</b><span>RUNTIME TODAY</span></div><div><b>${a.switches}</b><span>SWITCH-ONS</span></div><div><b>${a.peakW.toFixed(0)} W</b><span>PEAK POWER</span></div><div><b>${a.kwhToday.toFixed(3)}</b><span>kWh TODAY</span></div></div>
    <table><thead><tr><th>STATE</th><th>LEARNED NORMAL</th><th>NORMAL PF</th><th>BASELINE</th></tr></thead><tbody>${rows}</tbody></table>
    <div style="margin-top:12px"><button data-relearn="${a.id}">Re-learn normal from now</button>
      <span class="small muted" style="margin-left:8px">Run the appliance while it is known to be healthy.</span></div></div>`;
}

function line(el, ds, yTitle, opts) {
  return new Chart(el, { type: "line", data: { labels: [], datasets: ds },
    options: { maintainAspectRatio: false, animation: false, spanGaps: false, scales: { x: { ticks: { maxTicksLimit: 6 }, grid: { display: false } }, y: Object.assign({ title: { display: true, text: yTitle } }, opts || {}) }, plugins: { legend: { position: "bottom", labels: { boxWidth: 10 } } } } });
}

async function refresh() {
  let d; try { d = await getJSON("/api/health"); } catch (e) { return; }
  const open = document.activeElement && document.activeElement.dataset && document.activeElement.dataset.relearn;
  if (!open) $("cards").innerHTML = card(d.appliances.bulb, d.baseline) + card(d.appliances.fan, d.baseline);

  const hb = d.appliances.bulb.history, hf = d.appliances.fan.history;
  const times = (hf.length >= hb.length ? hf : hb).map((p) => clock(p.t));
  const pct = (h) => h.map((p) => (p.dev == null ? null : +(p.dev * 100).toFixed(1)));
  const pf = (h) => h.map((p) => p.pf);
  if (!devChart) {
    devChart = line($("dev"), [
      { label: "Bulb", data: [], borderColor: COLORS.amber, pointRadius: 0, borderWidth: 1.8, tension: .2 },
      { label: "Fan", data: [], borderColor: COLORS.teal, pointRadius: 0, borderWidth: 1.8, tension: .2 },
      { label: "Alert limit", data: [], borderColor: COLORS.red, borderDash: [6, 5], pointRadius: 0, borderWidth: 1.2 } ], "% above normal", { suggestedMin: -10, suggestedMax: 35 });
    pfChart = line($("pf"), [
      { label: "Bulb", data: [], borderColor: COLORS.amber, pointRadius: 0, borderWidth: 1.8, tension: .2 },
      { label: "Fan", data: [], borderColor: COLORS.teal, pointRadius: 0, borderWidth: 1.8, tension: .2 } ], "power factor", { min: 0.5, max: 1.05 });
  }
  const n = Math.max(hb.length, hf.length);
  const pad = (a) => a.length >= n ? a : new Array(n - a.length).fill(null).concat(a);
  devChart.data.labels = times.length >= n ? times : new Array(n).fill("").map((_, i) => times[i] || "");
  devChart.data.datasets[0].data = pad(pct(hb)); devChart.data.datasets[1].data = pad(pct(hf)); devChart.data.datasets[2].data = new Array(n).fill(20);
  devChart.update("none");
  pfChart.data.labels = devChart.data.labels; pfChart.data.datasets[0].data = pad(pf(hb)); pfChart.data.datasets[1].data = pad(pf(hf)); pfChart.update("none");

  // data quality
  const hw = d.hardware;
  if (d.mode !== "hardware") {
    $("dq").innerHTML = `<div class="note warn" style="margin:0"><b>Demo simulator in use.</b> There is no sensor data to cross-check yet. When the ESP32 posts, this table compares two independent energy totals: the one the server integrates from power, and the one the ESP32 counts itself. A gap of more than 3% means the sensors need calibrating.</div>`;
  } else {
    const rows = Object.values(hw.channels).map((c) => {
      const diff = c.moduleKwh != null && c.serverKwh > 0.0005 ? ((c.moduleKwh - c.serverKwh) / c.serverKwh) * 100 : null;
      const col = diff == null ? "" : Math.abs(diff) > 3 ? "color:var(--red)" : "color:var(--green)";
      return `<tr><td>${c.label}</td><td>${c.live ? '<span class="c-green">live</span>' : '<span class="c-red">offline</span>'}</td><td class="mono">${c.ageMs == null ? "--" : (c.ageMs / 1000).toFixed(1) + " s"}</td><td class="mono">${c.serverKwh.toFixed(4)}</td><td class="mono">${c.moduleKwh == null ? "--" : c.moduleKwh.toFixed(4)}</td><td class="mono" style="${col}">${diff == null ? "--" : diff.toFixed(1) + "%"}</td></tr>`;
    }).join("");
    $("dq").innerHTML = `<table><thead><tr><th>CHANNEL</th><th>LINK</th><th>LAST SEEN</th><th>SERVER kWh</th><th>ESP32 kWh</th><th>GAP</th></tr></thead><tbody>${rows}</tbody></table>`;
  }
}
document.addEventListener("click", async (e) => {
  const id = e.target.dataset && e.target.dataset.relearn; if (!id) return;
  await post("/api/health/relearn/" + id); e.target.textContent = "Learning for the next 2 minutes..."; e.target.blur(); setTimeout(refresh, 300);
});
refresh(); setInterval(refresh, 2000);
