let fc = null, cfgLoaded = false;

async function loadInsights() {
  try {
    const d = await getJSON("/api/insights");
    $("list").innerHTML = d.insights.length ? d.insights.map((i) => `<div class="ins ${i.sev}"><span class="dot"></span><div><div class="t">${esc(i.title)}</div><div class="d">${esc(i.detail)}</div></div></div>`).join("") : '<div class="empty">Not enough data yet.</div>';
  } catch (e) {}
}

async function loadForecast() {
  let d; try { d = await getJSON("/api/forecast"); } catch (e) { return; }
  $("demo-note").innerHTML = d.measuredDays < 7
    ? `<div class="note warn"><b>History before today is demo-generated.</b> Only ${d.measuredDays} day(s) of real data so far. Forecast, month estimate and habit insights use generated history until the rig has measured 7 days. Bars in grey below are generated; teal bars are measured.</div>` : "";
  $("fstats").innerHTML = `<div><b>${d.monthKwh.toFixed(1)} kWh</b><span>EXPECTED THIS MONTH</span></div><div><b>${rs(d.monthCost)}</b><span>ADDS TO YOUR BILL</span></div><div><b>${d.mape == null ? "--" : d.mape + " %"}</b><span>FORECAST ERROR (BACKTEST ${d.backtestDays} DAYS)</span></div>`;
  const labels = d.history.map((x) => x.date.slice(5)).concat(d.next.map((x) => x.dow + " " + x.date.slice(8)));
  const hist = d.history.map((x) => x.kwh).concat(d.next.map(() => null));
  const fut = d.history.map(() => null).concat(d.next.map((x) => x.kwh));
  const hcol = d.history.map((x) => (x.src === "hardware" || x.src === "virtual" ? COLORS.teal : "rgba(142,153,168,.55)")).concat(d.next.map(() => "rgba(242,169,59,.9)"));
  if (!fc) fc = new Chart($("fc"), { type: "bar", data: { labels, datasets: [{ label: "Measured / history", data: hist, backgroundColor: hcol, borderRadius: 3 }, { label: "Forecast", data: fut, backgroundColor: "rgba(242,169,59,.85)", borderRadius: 3 }] },
    options: { maintainAspectRatio: false, plugins: { legend: { position: "bottom", labels: { boxWidth: 10 } } }, scales: { y: { beginAtZero: true, title: { display: true, text: "kWh per day" } }, x: { stacked: true, grid: { display: false } } } } });
  else { fc.data.labels = labels; fc.data.datasets[0].data = hist; fc.data.datasets[0].backgroundColor = hcol; fc.data.datasets[1].data = fut; fc.update(); }
  $("fnote").textContent = `Method: each day is predicted from the average of the days around it (same weekday blended with the last 7 days). The error figure comes from predicting each of the last ${d.backtestDays} days using only the days before it. Basis: ${d.basis}.`;
}

async function loadConfig() {
  const c = await getJSON("/api/config");
  const set = (id, v) => { if (document.activeElement !== $(id)) $(id).value = v; };
  set("s-left", c.leftOnMinutes); set("s-qf", c.quietFrom); set("s-qt", c.quietTo); set("s-drag", Math.round(c.dragWarn * 100)); set("s-rest", c.restUnits);
}
const bind = (id, key, f) => $(id).addEventListener("change", async () => { await post("/api/config", { [key]: f ? f(+$(id).value) : +$(id).value }); loadInsights(); });
bind("s-left", "leftOnMinutes"); bind("s-qf", "quietFrom"); bind("s-qt", "quietTo"); bind("s-drag", "dragWarn", (x) => x / 100); bind("s-rest", "restUnits");

window.addEventListener("em:state", (e) => {
  const n = e.detail.notify;
  const on = n.telegram || n.webhook;
  $("notify").innerHTML = `<div style="font-size:13px;font-weight:600;margin-bottom:6px">Phone alerts: <span class="${on ? "c-green" : "c-amber"}">${on ? (n.telegram ? "Telegram" : "") + (n.telegram && n.webhook ? " + " : "") + (n.webhook ? "webhook" : "") + " connected" : "not set up"}</span></div>
    <p class="small muted" style="margin:0 0 8px">${on ? `Sent ${n.sent}, failed ${n.failed}${n.lastError ? ", last error: " + esc(n.lastError) : ""}.` : "Start the server with TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID set (see README) and every alert here also lands on your phone."}</p>
    <button id="tn" ${on ? "" : "disabled"}>Send test message</button>`;
  const b = $("tn"); if (b) b.onclick = async () => { b.textContent = "Sending..."; await post("/api/notify/test"); b.textContent = "Sent"; setTimeout(() => (b.textContent = "Send test message"), 1500); };
});
loadInsights(); loadForecast(); loadConfig();
setInterval(loadInsights, 6000); setInterval(loadForecast, 30000);
