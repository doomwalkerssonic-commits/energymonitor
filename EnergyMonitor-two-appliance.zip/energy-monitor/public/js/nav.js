// Shared navigation bar, data-source badge, story-mode banner, and one state poll for every page.
(function () {
  const PAGES = [
    ["/", "Overview"], ["/scope.html", "Scope"], ["/room.html", "Room"], ["/health.html", "Health"],
    ["/insights.html", "Insights"], ["/whatif.html", "What-if"], ["/hardware.html", "Hardware"],
  ];
  const here = location.pathname === "/index.html" ? "/" : location.pathname;
  const nav = document.createElement("nav");
  nav.innerHTML =
    '<span class="brand"><i></i>EnergyMonitor</span>' +
    PAGES.map(([h, n]) => `<a class="lnk${h === here ? " active" : ""}" href="${h}">${n}</a>`).join("") +
    '<span class="sp"></span>' +
    '<button id="nv-story" class="warn" style="margin-right:10px">&#9654; Story mode</button>' +
    '<span class="src simulated" id="nv-src" title="Where the numbers come from">DEMO SIMULATOR</span>';
  document.body.prepend(nav);

  const bar = document.createElement("div");
  bar.className = "storybar";
  bar.innerHTML = '<b>STORY MODE</b><span id="sb-label" style="flex:1"></span><span class="mono muted" id="sb-time"></span><div class="bar" style="flex:none;width:180px"><i id="sb-fill"></i></div><button id="sb-stop">Stop</button>';
  document.querySelector("main").prepend(bar);

  const LABEL = { hardware: "LIVE HARDWARE", virtual: "VIRTUAL ESP32", simulated: "DEMO SIMULATOR", offline: "ESP32 OFFLINE" };
  let last = null;

  function apply(s) {
    last = s;
    const a = s.appliances;
    let kind = "simulated";
    if (s.mode === "hardware") {
      const srcs = [a.bulb.src, a.fan.src];
      kind = srcs.includes("hardware") ? "hardware" : srcs.includes("virtual") ? "virtual" : "offline";
    }
    const el = document.getElementById("nv-src");
    el.className = "src " + kind; el.textContent = LABEL[kind];
    const sb = document.getElementById("nv-story");
    sb.disabled = s.mode !== "simulated";
    sb.title = s.mode !== "simulated" ? "Story mode needs the demo simulator (real hardware is connected)" : "Play a 100-second scripted demo";
    sb.textContent = s.story.running ? "■ Stop story" : "▶ Story mode";
    bar.classList.toggle("on", !!s.story.running);
    if (s.auth && !document.getElementById("nv-out")) { const o = document.createElement("button"); o.id = "nv-out"; o.textContent = "Log out"; o.style.marginLeft = "8px"; o.onclick = async () => { await post("/api/logout"); location.href = "/login.html"; }; document.querySelector("nav").appendChild(o); }
    if (s.story.running) {
      document.getElementById("sb-label").textContent = s.story.label;
      document.getElementById("sb-time").textContent = s.story.elapsed + " / " + s.story.total + " s";
      document.getElementById("sb-fill").style.width = Math.min(100, (s.story.elapsed / s.story.total) * 100) + "%";
    }
    window.dispatchEvent(new CustomEvent("em:state", { detail: s }));
  }

  async function poll() {
    try { apply(await getJSON("/api/state")); } catch (e) { /* server restarting */ }
  }
  document.getElementById("nv-story").onclick = async () => {
    try {
      if (last && last.story.running) await post("/api/story/stop"); else await post("/api/story/start");
      poll();
    } catch (e) { alert(e.message); }
  };
  document.getElementById("sb-stop").onclick = async () => { await post("/api/story/stop"); poll(); };
  window.EM = { last: () => last, refresh: poll };
  poll(); setInterval(poll, 1000);
})();
