const APPS = ["bulb", "fan"];
const ICON = {
  bulb: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><path d="M9 18h6M10 21h4M12 3a6 6 0 0 0-3.5 10.9c.6.5 1 1.2 1 2.1h5c0-.9.4-1.6 1-2.1A6 6 0 0 0 12 3z"/></svg>',
  fan: '<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round"><circle cx="12" cy="12" r="1.6"/><path d="M12 10.4C12 6 13.5 3 16 3.5c2 .5 1.6 3.5-1.5 6M13.6 12c4.4 0 7.4 1.5 6.9 4-.5 2-3.5 1.6-6-1.5M12 13.6c0 4.4-1.5 7.4-4 6.9-2-.5-1.6-3.5 1.5-6M10.4 12C6 12 3 10.5 3.5 8c.5-2 3.5-1.6 6 1.5"/></svg>',
};
let chart = null;

function appCard(a) {
  const hs = a.health;
  const hb = hs.score == null ? `<span class="hbadge ${hs.status}">${hs.status}</span>` : `<span class="hbadge ${hs.status}">health ${hs.score}</span>`;
  const st = a.online ? a.state : "offline";
  return `<a class="card app" href="/scope.html?id=${a.id}">
    <div class="top"><div class="name" style="display:flex;gap:9px;align-items:center;color:var(--${a.id === "bulb" ? "amber" : "teal"})">${ICON[a.id]}<span style="color:var(--text)">${a.label}</span></div>
      <div style="display:flex;gap:8px;align-items:center">${hb}<span class="chip ${st}">${a.online ? a.stateLabel : "OFFLINE"}</span></div></div>
    <div class="big">${fx(a.p, 1)}<small>W</small></div>
    <div class="kv"><div><b>${fx(a.i, 3)}</b><span>AMPS</span></div><div><b>${fx(a.pf, 2)}</b><span>PF</span></div><div><b>${fx(a.kwhToday, 3)}</b><span>kWh TODAY</span></div><div><b>${a.switches}</b><span>SWITCH-ONS</span></div></div>
  </a>`;
}

function renderAlerts(list) {
  const el = $("alerts");
  if (!list.length) { el.innerHTML = '<div class="empty">No alerts yet. Try Story mode.</div>'; return; }
  el.innerHTML = list.slice(0, 12).map((a) => `<div class="alert ${a.sev}${a.active ? "" : " done"}"><div class="t">${esc(a.title)}</div><div class="d">${esc(a.detail)}</div><div class="m">${clock(a.t)}${a.active ? " · ACTIVE" : " · resolved " + clock(a.resolvedAt)}</div></div>`).join("");
}

window.addEventListener("em:state", (e) => {
  const s = e.detail, b = s.appliances.bulb, f = s.appliances.fan;
  $("c-p").textContent = fx(b.p + f.p, 0);
  $("c-v").textContent = s.voltage ? fx(s.voltage, 1) : "--";
  $("c-f").textContent = "V  ·  " + fx(s.frequency, 1) + " Hz";
  $("c-e").textContent = fx(s.today.kwh, 3);
  $("c-c").textContent = rs(s.today.cost);
  $("c-r").textContent = "at Rs " + s.rate.toFixed(2) + " per unit";
  $("c-co").textContent = fx(s.today.co2, 3);
  $("apps").innerHTML = appCard(b) + appCard(f);
  renderAlerts(s.alerts);
});

async function drawPower() {
  try {
    const d = await getJSON("/api/power?sec=600");
    const labels = d.map((p) => clock(p.t).slice(0, 5));
    if (!chart) {
      chart = new Chart($("pw"), { type: "line",
        data: { labels, datasets: [
          { label: "Bulb", data: d.map((p) => p.bulb), borderColor: COLORS.amber, backgroundColor: "rgba(242,169,59,.35)", fill: true, pointRadius: 0, borderWidth: 1.6, tension: .25, stack: "a" },
          { label: "Fan", data: d.map((p) => p.fan), borderColor: COLORS.teal, backgroundColor: "rgba(79,209,197,.35)", fill: true, pointRadius: 0, borderWidth: 1.6, tension: .25, stack: "a" } ] },
        options: { maintainAspectRatio: false, animation: false, interaction: { mode: "index", intersect: false },
          scales: { x: { ticks: { maxTicksLimit: 6 }, grid: { display: false } }, y: { stacked: true, beginAtZero: true, title: { display: true, text: "Watts" }, suggestedMax: 100 } },
          plugins: { legend: { position: "bottom", labels: { boxWidth: 10 } } } } });
    } else {
      chart.data.labels = labels; chart.data.datasets[0].data = d.map((p) => p.bulb); chart.data.datasets[1].data = d.map((p) => p.fan); chart.update("none");
    }
  } catch (e) {}
}

async function drawTimeline() {
  try {
    const d = await getJSON("/api/timeline?sec=3600");
    const span = d.to - d.from;
    $("tl").innerHTML = APPS.map((id) => {
      const segs = d.segs[id];
      const bars = segs.map((s) => `<i class="s-${s.s}" style="width:${((s.to - s.from) / span) * 100}%" title="${s.s.toUpperCase()} ${clock(s.from)} to ${clock(s.to)}"></i>`).join("");
      return `<div class="tl-row"><span class="nm">${id === "bulb" ? "Bulb" : "Fan"}</span><div class="tl">${bars}</div></div>`;
    }).join("");
  } catch (e) {}
}

async function drawInsights() {
  try {
    const d = await getJSON("/api/insights");
    $("ins").innerHTML = d.insights.slice(0, 4).map((i) => `<div class="ins ${i.sev}"><span class="dot"></span><div><div class="t">${esc(i.title)}</div><div class="d">${esc(i.detail)}</div></div></div>`).join("") || '<div class="empty">Collecting data.</div>';
  } catch (e) {}
}

drawPower(); drawTimeline(); drawInsights();
setInterval(drawPower, 2000); setInterval(drawTimeline, 5000); setInterval(drawInsights, 8000);
