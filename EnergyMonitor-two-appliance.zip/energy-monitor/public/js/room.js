const SPIN = { low: 1.5, med: 0.85, high: 0.42 };
let simState = null;

function twin(a, color) {
  const exp = a.expected, dev = a.dev * 100;
  const max = Math.max(a.id === "bulb" ? 80 : 90, (exp || 0) * 1.5, a.p230 * 1.1);
  const pct = Math.min(100, (a.p230 / max) * 100), mark = exp ? Math.min(100, (exp / max) * 100) : 0;
  const hs = a.health;
  return `<h2 style="display:flex;justify-content:space-between;align-items:center">${a.label} <span class="hbadge ${hs.status}">${hs.score == null ? hs.status : "health " + hs.score}</span></h2>
    ${a.state === "off" || !a.online ? `<p class="muted small" style="margin:0">${a.online ? "Switched off." : "No data from this channel."}</p>` : `
    <div class="small muted">Measured, corrected to 230 V <b class="mono" style="color:var(--text)">${a.p230.toFixed(1)} W</b> &nbsp;·&nbsp; learned normal for ${a.stateLabel} <b class="mono" style="color:var(--amber)">${exp ? exp.toFixed(0) : "--"} W</b></div>
    <div class="bar"><div class="fill" style="width:${pct}%;background:${Math.abs(dev) > 20 ? "var(--red)" : Math.abs(dev) > 8 ? "var(--amber)" : color}"></div><div class="mark" style="left:${mark}%"></div></div>
    <div class="small" style="color:${Math.abs(dev) > 20 ? "var(--red)" : "var(--muted)"}">${dev >= 0 ? "+" : ""}${dev.toFixed(1)}% vs normal · ${hs.reasons[0]}</div>`}`;
}

window.addEventListener("em:state", (e) => {
  const s = e.detail, b = s.appliances.bulb, f = s.appliances.fan;
  simState = s.sim;
  $("t-bulb").textContent = (b.online ? b.p.toFixed(1) : "--") + " W";
  $("t-fan").textContent = (f.online ? f.p.toFixed(1) : "--") + " W";
  $("t-v").textContent = (s.voltage || 0).toFixed(0) + " V";
  $("t-fanstate").textContent = f.online ? f.stateLabel + (f.health.status === "check" || f.health.status === "watch" ? "  ·  CHECK ME" : "") : "OFFLINE";
  $("led").setAttribute("fill", (b.online || f.online) ? "#5CC98A" : "#5C6776");

  // bulb brightness follows real watts
  const br = b.online ? Math.min(1, b.p / 60) : 0;
  $("halo-c").setAttribute("opacity", (br * 0.75).toFixed(2));
  $("cone-poly").setAttribute("opacity", br.toFixed(2));
  $("bulb-glass").setAttribute("fill", br > 0.05 ? `rgba(255,200,87,${(0.25 + br * 0.6).toFixed(2)})` : "#1C232C");
  $("bulb-glass").setAttribute("stroke", br > 0.05 ? "#FFC857" : "#5C6776");
  $("fil").setAttribute("stroke", br > 0.05 ? "#FFF3C4" : "#5C6776");

  // fan speed from detected state; friction slows it and shakes it
  const bl = $("blades");
  const spin = SPIN[f.state];
  if (spin && f.online) {
    const slow = 1 + Math.max(0, f.dev) * 1.2;
    bl.style.animationDuration = (spin * slow).toFixed(2) + "s"; bl.style.animationPlayState = "running";
  } else bl.style.animationPlayState = "paused";
  $("fan-all").classList.toggle("shake", f.online && f.state !== "off" && f.dev > 0.12);
  $("ring").setAttribute("stroke", f.health.status === "check" ? "#EF5B5B" : f.health.status === "watch" ? "#F2A93B" : "#47566A");

  // wires pulse with current
  const wire = (id, a) => { const w = $(id); const on = a.online && a.i > 0.02; w.classList.toggle("off", !on); w.style.animationDuration = Math.max(0.25, 1.3 - a.i * 2.5).toFixed(2) + "s"; };
  wire("w-bulb", b); wire("w-fan", f);

  $("tw-bulb").innerHTML = twin(b, "var(--amber)");
  $("tw-fan").innerHTML = twin(f, "var(--teal)");

  // controls
  const live = s.mode === "simulated";
  document.querySelectorAll("#ctl button").forEach((x) => {
    x.disabled = !live;
    if (!live || !simState) { x.classList.remove("sel"); return; }
    const a = x.dataset.a, v = x.dataset.v;
    const on = (a === "bulb" && (simState.bulbOn ? "1" : "0") === v) || (a === "fan" && String(simState.fanSpeed) === v) || (a === "drag" && simState.drag) || (a === "sag" && simState.sag);
    x.classList.toggle("sel", !!on);
  });
  $("ctlnote").textContent = live ? "These switch the built-in simulator. Everything else on the page reacts the same way it would to real hardware." : "Real hardware is posting data, so the simulator controls are off. Switch the real bulb and fan instead.";
});

$("ctl").addEventListener("click", async (e) => {
  const b = e.target.closest("button"); if (!b || b.disabled) return;
  const a = b.dataset.a, body = {};
  if (a === "bulb") body.bulb = b.dataset.v === "1";
  else if (a === "fan") body.fan = +b.dataset.v;
  else if (a === "drag") body.drag = !(simState && simState.drag);
  else if (a === "sag") body.sag = !(simState && simState.sag);
  try { await post("/api/control", body); EM.refresh(); } catch (err) { alert(err.message); }
});
