let sel = new URLSearchParams(location.search).get("id") === "fan" ? "fan" : "bulb";
let frozen = false, data = null, harmChart = null;

function setup(cv) {
  const dpr = window.devicePixelRatio || 1, w = cv.clientWidth, h = +cv.getAttribute("height");
  if (cv.width !== w * dpr) { cv.width = w * dpr; cv.height = h * dpr; }
  const c = cv.getContext("2d"); c.setTransform(dpr, 0, 0, dpr, 0, 0);
  return { c, w, h };
}

function grid(c, w, h, cycles, ms) {
  c.strokeStyle = "rgba(120,140,160,.13)"; c.lineWidth = 1; c.beginPath();
  for (let k = 0; k <= cycles * 4; k++) { const x = (k / (cycles * 4)) * w; c.moveTo(x, 0); c.lineTo(x, h); }
  for (let k = 0; k <= 8; k++) { const y = (k / 8) * h; c.moveTo(0, y); c.lineTo(w, y); }
  c.stroke();
  c.strokeStyle = "rgba(160,175,190,.35)"; c.beginPath(); c.moveTo(0, h / 2); c.lineTo(w, h / 2); c.stroke();
  c.fillStyle = "rgba(142,153,168,.7)"; c.font = "10px 'JetBrains Mono',monospace";
  for (let k = 0; k <= cycles * 2; k++) c.fillText(k * 10 + " ms", Math.min(w - 36, (k / (cycles * 2)) * w + 3), h - 4);
}

function trace(c, arr, w, h, pk, color, glow) {
  c.save(); c.strokeStyle = color; c.lineWidth = 2; c.lineJoin = "round"; c.shadowColor = color; c.shadowBlur = glow;
  c.beginPath();
  for (let k = 0; k < arr.length; k++) {
    const x = (k / (arr.length - 1)) * w, y = h / 2 - (arr[k] / pk) * (h / 2) * 0.9;
    k ? c.lineTo(x, y) : c.moveTo(x, y);
  }
  c.stroke(); c.restore();
}

function drawWave(m, d) {
  const { c, w, h } = setup($("wave"));
  c.clearRect(0, 0, w, h); grid(c, w, h, d.cycles, 20);
  const vpk = 360, ipk = Math.max(0.5, Math.ceil(m.pkI * 1.3 * 10) / 10);
  trace(c, m.vv, w, h, vpk, "#F2A93B", 6);
  trace(c, m.ii, w, h, ipk, "#4FD1C5", 8);
  $("scales").textContent = `V: ±${vpk} V   I: ±${ipk.toFixed(1)} A`;
}

function drawPower(m, d) {
  const { c, w, h } = setup($("pwr"));
  c.clearRect(0, 0, w, h); grid(c, w, h, d.cycles, 20);
  const pk = Math.max(20, Math.max(...m.pw.map(Math.abs)) * 1.15), mid = h / 2;
  const y = (v) => mid - (v / pk) * mid * 0.9;
  c.beginPath(); c.moveTo(0, mid);
  m.pw.forEach((p, k) => c.lineTo((k / (m.pw.length - 1)) * w, y(p)));
  c.lineTo(w, mid); c.closePath(); c.fillStyle = "rgba(143,163,255,.28)"; c.fill();
  // paint negative lobes teal
  c.save(); c.beginPath(); c.rect(0, mid, w, h); c.clip();
  c.beginPath(); c.moveTo(0, mid); m.pw.forEach((p, k) => c.lineTo((k / (m.pw.length - 1)) * w, y(p))); c.lineTo(w, mid); c.closePath();
  c.fillStyle = "rgba(79,209,197,.55)"; c.fill(); c.restore();
  c.strokeStyle = "#8FA3FF"; c.lineWidth = 1.8; c.beginPath();
  m.pw.forEach((p, k) => { const x = (k / (m.pw.length - 1)) * w; k ? c.lineTo(x, y(p)) : c.moveTo(x, y(p)); });
  c.stroke();
  c.strokeStyle = "#F2A93B"; c.setLineDash([6, 5]); c.beginPath(); c.moveTo(0, y(m.p)); c.lineTo(w, y(m.p)); c.stroke(); c.setLineDash([]);
  c.fillStyle = "#F2A93B"; c.font = "bold 12px 'JetBrains Mono',monospace"; c.fillText("average = " + m.p.toFixed(1) + " W (real power)", 10, 16);
}

function drawPhasor(m) {
  const { c, w, h } = setup($("ph"));
  c.clearRect(0, 0, w, h);
  const R = Math.min(72, h / 2 - 14), cx = R + 20, cy = h / 2;
  c.strokeStyle = "rgba(160,175,190,.25)"; c.lineWidth = 1;
  c.beginPath(); c.arc(cx, cy, R, 0, 7); c.moveTo(cx - R - 8, cy); c.lineTo(cx + R + 8, cy); c.moveTo(cx, cy - R - 8); c.lineTo(cx, cy + R + 8); c.stroke();
  const arrow = (ang, len, col, lab, dy) => {
    const x = cx + Math.cos(ang) * len, y = cy - Math.sin(ang) * len;
    c.strokeStyle = col; c.fillStyle = col; c.lineWidth = 2.4;
    c.beginPath(); c.moveTo(cx, cy); c.lineTo(x, y); c.stroke();
    c.beginPath(); c.moveTo(x, y); c.lineTo(x - Math.cos(ang - .35) * 9, y + Math.sin(ang - .35) * 9); c.lineTo(x - Math.cos(ang + .35) * 9, y + Math.sin(ang + .35) * 9); c.closePath(); c.fill();
    c.font = "bold 12px 'JetBrains Mono',monospace"; c.fillText(lab, cx + R + 10, cy + dy);
  };
  const phi = m.irms < 0.02 ? 0 : -m.phi * Math.PI / 180;      // current lags voltage -> drawn clockwise
  arrow(phi, R * 0.82, "#4FD1C5", "I", phi < -0.05 ? 18 : 16);
  arrow(0, R, "#F2A93B", "V", -6);
  if (Math.abs(phi) > 0.03) { c.strokeStyle = "#E8EBEF"; c.lineWidth = 1.2; c.beginPath(); c.arc(cx, cy, 30, Math.min(0, phi), Math.max(0, phi)); c.stroke(); }
  c.fillStyle = "#E8EBEF"; c.font = "12px 'JetBrains Mono',monospace";
  c.fillText(Math.abs(m.phi) < 0.5 || m.irms < 0.02 ? "in phase" : "φ = " + Math.abs(m.phi).toFixed(1) + "° (I lags V)", 8, 14);

  // power triangle
  const ox = cx + R + 56, avail = w - ox - 10, oy = h - 40;
  if (avail > 60) {
    const sc = Math.min(avail, 150) / Math.max(m.s, 1);
    const pw = m.p * sc, qh = Math.max(m.q * sc, 0);
    c.lineWidth = 1; c.strokeStyle = "rgba(160,175,190,.3)";
    c.beginPath(); c.moveTo(ox, oy); c.lineTo(ox + pw, oy); c.lineTo(ox + pw, oy - qh); c.closePath(); c.fillStyle = "rgba(143,163,255,.12)"; c.fill(); c.stroke();
    c.lineWidth = 2.4;
    c.strokeStyle = "#E07B3F"; c.beginPath(); c.moveTo(ox, oy); c.lineTo(ox + pw, oy); c.stroke();
    c.strokeStyle = "#4FD1C5"; c.beginPath(); c.moveTo(ox + pw, oy); c.lineTo(ox + pw, oy - qh); c.stroke();
    c.strokeStyle = "#8FA3FF"; c.beginPath(); c.moveTo(ox, oy); c.lineTo(ox + pw, oy - qh); c.stroke();
    c.font = "11.5px 'JetBrains Mono',monospace";
    c.fillStyle = "#E07B3F"; c.fillText("P  " + m.p.toFixed(1) + " W", ox, oy + 18);
    c.fillStyle = "#4FD1C5"; c.fillText("Q  " + m.q.toFixed(1) + " var", ox, oy + 34);
    c.fillStyle = "#8FA3FF"; c.fillText("S  " + m.s.toFixed(1) + " VA", ox, oy - 78);
  }
}

function metrics(m) {
  const cells = [
    ["Vrms", m.vrms.toFixed(1) + " V"], ["Irms", m.irms.toFixed(3) + " A"],
    ["Real power P", m.p.toFixed(1) + " W"], ["Apparent S", m.s.toFixed(1) + " VA"],
    ["Reactive Q", m.q.toFixed(1) + " var"], ["Power factor", m.pf.toFixed(3)],
    ["Phase angle", m.irms < 0.02 ? "--" : (Math.abs(m.phi) < 0.5 ? "0.0° (in phase)" : Math.abs(m.phi).toFixed(1) + "° " + (m.phi >= 0 ? "lag" : "lead"))], ["Current THD", m.thdI.toFixed(1) + " %"],
    ["Crest factor I", m.crestI.toFixed(2)], ["Voltage THD", m.thdV.toFixed(1) + " %"],
  ];
  $("mg").innerHTML = cells.map(([k, v]) => `<div><b>${v}</b><span>${k.toUpperCase()}</span></div>`).join("");
}

function harmonics(m) {
  const fund = m.harmonicsI[0] || 1;
  const labels = [], vals = [];
  for (let h = 2; h <= 15; h++) { labels.push("H" + h); vals.push(m.irms < 0.02 ? 0 : (m.harmonicsI[h - 1] / fund) * 100); }
  if (!harmChart) {
    harmChart = new Chart($("hm"), { type: "bar", data: { labels, datasets: [{ data: vals, backgroundColor: "rgba(242,169,59,.8)", borderRadius: 3 }] },
      options: { maintainAspectRatio: false, animation: false, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, suggestedMax: 6, title: { display: true, text: "% of fundamental" } }, x: { grid: { display: false } } } } });
  } else { harmChart.data.datasets[0].data = vals; harmChart.update("none"); }
}

function render(d) {
  const note = $("srcnote");
  if (d.src === "offline") { note.textContent = "No data from this channel."; return; }
  note.textContent = d.src === "raw"
    ? "Raw samples captured by the ESP32 (ZMPT101B and ACS712)."
    : "Demo waveform rebuilt from RMS and power factor. With the ESP32 posting raw samples this becomes the real captured wave.";
  const m = analyze(d.v, d.i, d.cycles);
  drawWave(m, d); drawPower(m, d); drawPhasor(m); metrics(m); harmonics(m);
}

async function poll() {
  if (frozen) return;
  try { data = await getJSON("/api/scope/" + sel); render(data); } catch (e) {}
}

document.querySelectorAll("#tabs button").forEach((b) => {
  b.classList.toggle("sel", b.dataset.id === sel);
  b.onclick = () => { sel = b.dataset.id; document.querySelectorAll("#tabs button").forEach((x) => x.classList.toggle("sel", x === b)); frozen = false; $("freeze").textContent = "Freeze"; poll(); };
});
$("freeze").onclick = () => { frozen = !frozen; $("freeze").textContent = frozen ? "Resume" : "Freeze"; $("freeze").classList.toggle("sel", frozen); };
window.addEventListener("resize", () => data && render(data));
poll(); setInterval(poll, 350);
