let ba = null, timer = null, limitsSet = false;

function q() {
  return new URLSearchParams({ bulbCut: $("bc").value, fanCut: $("fcut").value, led: $("led").checked ? 1 : 0, fanDown: $("down").checked ? 1 : 0, rest: $("rest").value }).toString();
}

async function run() {
  $("o-bc").textContent = $("bc").value + " h"; $("o-fc").textContent = $("fcut").value + " h"; $("o-rest").textContent = $("rest").value;
  let d; try { d = await getJSON("/api/whatif?" + q()); } catch (e) { return; }
  if (!limitsSet) {
    limitsSet = true;
    $("bc").max = Math.floor(d.limits.bulbMax * 4) / 4; $("fcut").max = Math.floor(d.limits.fanMax * 4) / 4;
  }
  const s = d.saving;
  $("r-rs").textContent = rs(s.cost); $("r-yr").textContent = "about " + rs(s.yearCost) + " a year";
  $("r-kwh").textContent = s.kwh.toFixed(1); $("r-pct").textContent = "kWh a month  ·  " + s.pct.toFixed(0) + "% less";
  $("r-co").textContent = s.co2.toFixed(1);
  const data = [[d.before.bulb, d.before.fan], [d.after.bulb, d.after.fan]];
  if (!ba) ba = new Chart($("ba"), { type: "bar", data: { labels: ["Now", "With your changes"], datasets: [
      { label: "Bulb", data: [data[0][0], data[1][0]], backgroundColor: COLORS.amber, borderRadius: 3 },
      { label: "Fan", data: [data[0][1], data[1][1]], backgroundColor: COLORS.teal, borderRadius: 3 } ] },
    options: { indexAxis: "y", maintainAspectRatio: false, animation: { duration: 250 }, plugins: { legend: { position: "bottom", labels: { boxWidth: 10 } } }, scales: { x: { stacked: true, title: { display: true, text: "kWh a month" }, beginAtZero: true }, y: { stacked: true, grid: { display: false } } } } });
  else { ba.data.datasets[0].data = [data[0][0], data[1][0]]; ba.data.datasets[1].data = [data[0][1], data[1][1]]; ba.update(); }

  // slab strip
  const rest = +$("rest").value, tot = rest + d.before.kwh, totAfter = rest + d.after.kwh;
  const edges = d.slabs.map((x) => x.upto == null ? 700 : x.upto);
  const cols = ["#4FD1C5", "#8FA3FF", "#F2A93B", "#E07B3F"];
  let prev = 0; const maxU = 700;
  $("slabs").innerHTML = d.slabs.map((sl, k) => { const w = ((edges[k] - prev) / maxU) * 100; const lab = `${prev}-${sl.upto == null ? "+" : sl.upto} · Rs ${sl.rate}`; prev = edges[k]; return `<div style="width:${w}%;background:${cols[k]}">${lab}</div>`; }).join("")
    + `<div class="pin" style="left:${Math.min(99, (tot / maxU) * 100)}%" title="now"></div>`
    + `<div class="pin" style="left:${Math.min(99, (totAfter / maxU) * 100)}%;background:var(--green)" title="after"></div>`;
  $("slabnote").innerHTML = `White pin: now (${tot.toFixed(0)} kWh a month in total). Green pin: after your changes (${totAfter.toFixed(0)} kWh).`;
  const det = d.basis;
  $("demo-note").innerHTML = det.measuredDays < 7 ? `<div class="note warn"><b>Habits are from demo-generated history</b> (${det.measuredDays} measured day(s) so far): the bulb averages ${det.bulbHoursPerDay} h and the fan ${det.fanHoursPerDay} h a day. These switch to measured habits automatically after 7 days of real data.</div>` : "";
}
["bc", "fcut", "led", "down", "rest"].forEach((id) => $(id).addEventListener("input", () => { clearTimeout(timer); timer = setTimeout(run, 60); }));
run();
