// Optional password login + ESP32 device key. Both switch on only when you set the
// environment variables, so running on your laptop needs no setup at all.
//   APP_PASSWORD   password for the website (login page appears when set)
//   SESSION_SECRET long random text used to sign login cookies (set it so logins survive restarts)
//   DEVICE_KEY     secret the ESP32 must send in the "x-device-key" header
const crypto = require("crypto");

const PASSWORD = process.env.APP_PASSWORD || "";
const DEVICE_KEY = process.env.DEVICE_KEY || "";
const SECRET = process.env.SESSION_SECRET || crypto.randomBytes(32).toString("hex");
const COOKIE = "em_session";
const WEEK = 7 * 24 * 3600 * 1000;

const sign = (v) => crypto.createHmac("sha256", SECRET).update(v).digest("hex");
const same = (a, b) => {
  const x = crypto.createHash("sha256").update(String(a)).digest();
  const y = crypto.createHash("sha256").update(String(b)).digest();
  return crypto.timingSafeEqual(x, y);
};

function token() { const p = String(Date.now() + WEEK); return p + "." + sign(p); }
function validToken(t) {
  if (!t || !t.includes(".")) return false;
  const [p, s] = t.split(".");
  return same(s, sign(p)) && Number(p) > Date.now();
}
function cookieOf(req) {
  const m = (req.headers.cookie || "").split(/;\s*/).find((c) => c.startsWith(COOKIE + "="));
  return m ? decodeURIComponent(m.slice(COOKIE.length + 1)) : "";
}

const OPEN = new Set(["/login.html", "/api/login", "/css/style.css", "/healthz", "/api/hardware/reading"]);
function gate(req, res, next) {
  if (!PASSWORD || OPEN.has(req.path) || validToken(cookieOf(req))) return next();
  if (req.path.startsWith("/api/")) return res.status(401).json({ error: "Login required" });
  res.redirect("/login.html");
}

// ESP32 posts: if DEVICE_KEY is set it must match.
function deviceGate(req, res, next) {
  if (!DEVICE_KEY || same(req.headers["x-device-key"] || "", DEVICE_KEY)) return next();
  res.status(401).json({ error: "Bad or missing x-device-key" });
}

const tries = {};
function login(req, res) {
  const ip = req.ip || "x", now = Date.now();
  const t = (tries[ip] = (tries[ip] || []).filter((x) => now - x < 60000));
  if (t.length >= 8) return res.status(429).json({ error: "Too many attempts. Wait a minute." });
  t.push(now);
  if (!PASSWORD || !same((req.body && req.body.password) || "", PASSWORD)) return res.status(401).json({ error: "Wrong password" });
  const secure = req.secure || req.headers["x-forwarded-proto"] === "https";
  res.setHeader("Set-Cookie", `${COOKIE}=${encodeURIComponent(token())}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${WEEK / 1000}${secure ? "; Secure" : ""}`);
  res.json({ ok: true });
}
function logout(req, res) {
  res.setHeader("Set-Cookie", `${COOKIE}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0`);
  res.json({ ok: true });
}

module.exports = { gate, deviceGate, login, logout, enabled: !!PASSWORD, deviceKeyOn: !!DEVICE_KEY };
