// Real (or virtual) ESP32 readings.
// Hardware: 1 shared ZMPT101B voltage sensor + 1 ACS712-05B current sensor per appliance.
// The ESP32 posts one JSON per appliance per second. It may also attach one captured
// mains cycle ("wave") so the Scope page can draw the real waveform.
const STALE_MS = 5000;

const CHANNELS = {
  bulb: { label: "Bulb", sensor: "ACS712-05B #1", rated: 60 },
  fan:  { label: "Table fan", sensor: "ACS712-05B #2", rated: 75 },
};

const store = {};   // id -> latest reading
let lastSrc = null;
let everSeen = false;

function isNums(a, lo, hi) {
  return Array.isArray(a) && a.length >= 32 && a.length <= 1024 &&
    a.every((x) => Number.isFinite(x) && Math.abs(x) <= hi && Math.abs(x) >= lo);
}

function validate(b) {
  if (!b || !CHANNELS[b.id]) return "unknown device id (use bulb or fan)";
  for (const k of ["v", "i", "p"]) if (!Number.isFinite(b[k])) return k + " must be a number";
  if (b.v < 80 || b.v > 300) return "voltage out of range (80 to 300 V)";
  if (b.i < 0 || b.i > 6) return "current out of range (0 to 6 A; the ACS712-05B reads +-5 A)";
  if (b.p < 0 || b.p > 1500) return "power out of range (0 to 1500 W)";
  if (b.wave != null) {
    const w = b.wave;
    if (!w || !isNums(w.v, 0, 500) || !isNums(w.i, 0, 10) || w.v.length !== w.i.length)
      return "wave must be {v:[...], i:[...]} with equal length 32-1024 (volts, amps)";
  }
  return null;
}

function ingest(b) {
  const now = Date.now();
  const prev = store[b.id];
  let serverKwh = prev ? prev.serverKwh : 0;
  if (prev) {
    const dt = Math.min((now - prev.t) / 3600000, 10 / 3600);   // cap gaps at 10 s
    serverKwh += (b.p / 1000) * dt;
  }
  store[b.id] = {
    v: b.v, i: b.i, p: b.p,
    kwh: Number.isFinite(b.kwh) ? b.kwh : null,
    f: Number.isFinite(b.f) ? b.f : null,
    pf: Number.isFinite(b.pf) ? b.pf : null,
    wave: b.wave ? { v: b.wave.v, i: b.wave.i, cycles: Math.min(4, Math.max(1, Math.round(b.wave.cycles || 1))) } : (prev ? prev.wave : null),
    waveT: b.wave ? now : (prev ? prev.waveT : null),
    t: now, src: b.src || "esp32", serverKwh,
    startKwh: prev ? prev.startKwh : (Number.isFinite(b.kwh) ? b.kwh : null),
  };
  lastSrc = store[b.id].src;
  everSeen = true;
}

function fresh(id) {
  const r = store[id];
  return r && Date.now() - r.t < STALE_MS ? r : null;
}

function seen() { return everSeen; }

function freshWave(id) {
  const r = fresh(id);
  return r && r.wave && Date.now() - r.waveT < 3000 ? r.wave : null;
}

function snapshot() {
  const out = { staleAfterMs: STALE_MS, source: lastSrc, everSeen, channels: {} };
  for (const id of Object.keys(CHANNELS)) {
    const r = store[id];
    const ageMs = r ? Date.now() - r.t : null;
    const live = !!r && ageMs < STALE_MS;
    const moduleKwh = r && r.kwh != null && r.startKwh != null ? r.kwh - r.startKwh : null;
    out.channels[id] = {
      ...CHANNELS[id], id, live, ageMs,
      v: r ? r.v : null, i: r ? r.i : null, p: r ? r.p : null,
      f: r ? r.f : null, pf: r ? r.pf : null, hasWave: !!(r && r.wave),
      serverKwh: r ? Number(r.serverKwh.toFixed(5)) : 0,
      moduleKwh: moduleKwh == null ? null : Number(moduleKwh.toFixed(5)),
    };
  }
  return out;
}

module.exports = { CHANNELS, validate, ingest, fresh, freshWave, seen, snapshot, STALE_MS };
