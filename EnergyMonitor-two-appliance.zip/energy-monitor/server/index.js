const express = require("express");
const path = require("path");
const hw = require("./hardware");
const sim = require("./sim");
const twin = require("./twin");
const ins = require("./insights");
const notify = require("./notify");
const auth = require("./auth");

const app = express();
app.set("trust proxy", 1);
app.use((req, res, next) => { res.setHeader("X-Content-Type-Options", "nosniff"); res.setHeader("Referrer-Policy", "same-origin"); next(); });
app.use(express.json({ limit: "256kb" }));
app.get("/healthz", (req, res) => res.send("ok"));
app.post("/api/login", auth.login);
app.post("/api/logout", auth.logout);
app.use(auth.gate);
app.use(express.static(path.join(__dirname, "..", "public")));

// ---- ESP32 ingest ----
app.post("/api/hardware/reading", auth.deviceGate, (req, res) => {
  const err = hw.validate(req.body);
  if (err) return res.status(400).json({ error: err });
  hw.ingest(req.body);
  res.sendStatus(204);
});
app.get("/api/hardware", (req, res) => res.json({ ...hw.snapshot(), mode: twin.mode() }));

// ---- Everything the Overview page needs ----
app.get("/api/state", (req, res) => {
  const rate = ins.ratePerKwh();
  const bulb = twin.applianceView("bulb"), fan = twin.applianceView("fan");
  const today = bulb.kwhToday + fan.kwhToday;
  res.json({
    now: Date.now(), mode: twin.mode(), story: sim.storyInfo(),
    voltage: twin.sharedV, frequency: twin.sharedF,
    appliances: { bulb, fan },
    today: { kwh: today, cost: today * rate, co2: ins.co2Of(today) },
    rate, config: twin.config, notify: notify.status, auth: auth.enabled,
    sim: twin.mode() === "simulated" ? { bulbOn: sim.s.bulbOn, fanSpeed: sim.s.fanSpeed, drag: sim.s.dragTarget > 0, sag: sim.s.sag } : null,
    alerts: twin.alerts.slice(0, 20),
  });
});

app.get("/api/power", (req, res) => {
  const sec = Math.min(3600, Math.max(30, +req.query.sec || 600));
  const bucket = Math.max(1, Math.round(sec / 240));
  res.json(twin.powerSeries(sec, bucket));
});
app.get("/api/timeline", (req, res) => res.json(twin.segments(Math.min(6 * 3600, Math.max(300, +req.query.sec || 3600)) * 1000)));
app.get("/api/scope/:id", (req, res) => {
  if (!twin.IDS.includes(req.params.id)) return res.status(404).json({ error: "unknown appliance" });
  res.json(twin.scope(req.params.id));
});
app.get("/api/health", (req, res) => {
  const out = { baseline: twin.baseline, appliances: {}, mode: twin.mode() };
  for (const id of twin.IDS) out.appliances[id] = { ...twin.applianceView(id), history: twin.devHist(id) };
  out.hardware = hw.snapshot();
  res.json(out);
});
app.post("/api/health/relearn/:id", (req, res) => {
  if (!twin.IDS.includes(req.params.id)) return res.status(404).json({ error: "unknown appliance" });
  twin.relearn(req.params.id); res.json({ ok: true });
});
app.post("/api/health/reset", (req, res) => { twin.resetBaseline(); res.json({ ok: true }); });

// ---- Analytics ----
app.get("/api/insights", (req, res) => res.json({ insights: ins.insights(), rate: ins.ratePerKwh(), co2: twin.config.co2 }));
app.get("/api/forecast", (req, res) => res.json(ins.forecast()));
app.get("/api/whatif", (req, res) => res.json(ins.whatif(req.query)));

// ---- Controls (simulator only) ----
app.post("/api/control", (req, res) => {
  if (!twin.control(req.body || {})) return res.status(409).json({ error: "Real hardware is connected. Controls only work in demo-simulator mode." });
  res.json({ ok: true });
});
app.post("/api/story/start", (req, res) => {
  if (twin.mode() !== "simulated") return res.status(409).json({ error: "Story mode only runs on the demo simulator." });
  sim.startStory(twin.storyHooks());
  res.json(sim.storyInfo());
});
app.post("/api/story/stop", (req, res) => { sim.stopStory(); res.json({ ok: true }); });

app.get("/api/config", (req, res) => res.json(twin.config));
app.post("/api/config", (req, res) => res.json(twin.setConfig(req.body || {})));
app.post("/api/notify/test", async (req, res) => {
  await notify.send("EnergyMonitor test message: phone alerts are working.");
  res.json(notify.status);
});

app.get("/api/export.csv", (req, res) => {
  let csv = "hour,bulb_kwh,fan_kwh,total_kwh,source\n";
  Object.keys(twin.hours).sort().forEach((k) => {
    const h = twin.hours[k];
    csv += `${k}:00,${h.bulb.toFixed(5)},${h.fan.toFixed(5)},${(h.bulb + h.fan).toFixed(5)},${h.src}\n`;
  });
  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=energy_history.csv");
  res.send(csv);
});

twin.start();
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`EnergyMonitor running -> http://localhost:${PORT}`));
