// Plain-English insights, forecast and what-if savings. Everything here is rule-based
// arithmetic on measured data, so each sentence can be traced back to numbers.
const tariff = require("./tariff");
const twin = require("./twin");

// Monthly bill part that depends on units (fixed charge and meter rent are the same either way).
function monthlyCost(units) {
  const energy = tariff.slabEnergyCharge(units);
  const trueUp = units * tariff.TRUE_UP_PER_UNIT;
  return (energy + trueUp) * (1 + tariff.ELECTRICITY_DUTY);
}
function marginal(rest, extra) { return monthlyCost(rest + extra) - monthlyCost(rest); }

function completeDays() {
  const today = new Date();
  const tk = `${today.getFullYear()}-${String(today.getMonth() + 1).padStart(2, "0")}-${String(today.getDate()).padStart(2, "0")}`;
  return twin.dailyTotals().filter((d) => d.date < tk);
}

function baseDaily() {
  const days = completeDays().slice(-7);
  const n = days.length || 1;
  const sum = (k) => days.reduce((s, d) => s + d[k], 0) / n;
  const measured = days.filter((d) => d.src === "hardware" || d.src === "virtual").length;
  return { bulb: sum("bulb"), fan: sum("fan"), total: sum("total"), days: days.length, measuredDays: measured };
}

function ratePerKwh() {
  const b = baseDaily();
  const month = Math.max(0.5, b.total * 30);
  return marginal(twin.config.restUnits, month) / month;
}

const money = (x) => "Rs " + (x >= 100 ? x.toFixed(0) : x.toFixed(2));
const co2Of = (kwh) => kwh * twin.config.co2;

function insights() {
  const out = [];
  const rate = ratePerKwh();
  const b = baseDaily();
  const bv = twin.applianceView("bulb"), fv = twin.applianceView("fan");
  const tb = bv.kwhToday, tf = fv.kwhToday, tt = tb + tf;
  const now = new Date();

  // today vs yesterday at the same time
  const days = twin.dailyTotals();
  const todayK = days.length ? days[days.length - 1] : null;
  const yest = completeDays().slice(-1)[0];
  if (yest) {
    let ySoFar = 0;
    for (let h = 0; h <= now.getHours(); h++) ySoFar += yest.hours[h] || 0;
    if (ySoFar > 0.01 && tt > 0.005) {
      const pct = ((tt - ySoFar) / ySoFar) * 100;
      out.push({ id: "vsyest", sev: pct > 15 ? "warn" : pct < -15 ? "good" : "info",
        title: pct > 0 ? `${pct.toFixed(0)}% more than yesterday so far` : `${(-pct).toFixed(0)}% less than yesterday so far`,
        detail: `Up to this hour you used ${tt.toFixed(3)} kWh (${money(tt * rate)}). Yesterday, by the same hour, it was ${ySoFar.toFixed(3)} kWh.` });
    }
  }

  // who uses the energy
  if (tt > 0.005) {
    const big = tf >= tb ? ["Fan", tf] : ["Bulb", tb];
    out.push({ id: "share", sev: "info", title: `${big[0]} is using ${(big[1] / tt * 100).toFixed(0)}% of today's energy`,
      detail: `Bulb ${tb.toFixed(3)} kWh, fan ${tf.toFixed(3)} kWh. Total ${tt.toFixed(3)} kWh, about ${money(tt * rate)} at your current slab.` });
  }

  // fan speed habit
  const rt = twin.runtime("fan");
  const fanSec = rt.low + rt.med + rt.high;
  if (fanSec > 60 && rt.high > 0.3 * fanSec) {
    const fanBase = twin.baseline.fan;
    const dW = fanBase.high.w - fanBase.med.w;
    const monthHours = (rt.high / 3600) * 30;
    out.push({ id: "fanhigh", sev: "info", title: `Fan ran on HIGH for ${Math.round(rt.high / 60)} min today`,
      detail: `Medium speed draws about ${dW.toFixed(0)} W less. If this repeats daily, medium would save ${(monthHours * dW / 1000).toFixed(2)} kWh a month (${money(marginal(twin.config.restUnits, monthHours * dW / 1000))}).` });
  }

  // bulb to LED
  if (b.bulb > 0.01) {
    const hrs = b.bulb * 1000 / 60;
    const saveKwh = hrs * (60 - 9) / 1000 * 30;
    out.push({ id: "led", sev: "good", title: "A 9 W LED would do the bulb's job",
      detail: `The bulb runs about ${hrs.toFixed(1)} h a day. Swapping 60 W for 9 W saves ${saveKwh.toFixed(1)} kWh a month, ${money(marginal(twin.config.restUnits, b.total * 30) - marginal(twin.config.restUnits, Math.max(0, b.total * 30 - saveKwh)))} on the bill and ${co2Of(saveKwh).toFixed(1)} kg of CO2.`, rs: 1 });
  }

  // peak-hour share (last 7 days)
  const last7 = completeDays().slice(-7);
  if (last7.length) {
    let tot = 0, peak = 0;
    for (const d of last7) for (const h in d.hours) { tot += d.hours[h]; if (tariff.PEAK_HOURS.has(+h)) peak += d.hours[h]; }
    if (tot > 0) {
      const share = peak / tot, dayPeak = peak / last7.length;
      out.push({ id: "peak", sev: share > 0.4 ? "warn" : "info", title: `${(share * 100).toFixed(0)}% of your energy falls in the 6 to 10 pm peak`,
        detail: `Time-of-day tariffs add about ${tariff.TOD_ADJUSTMENT * 100}% on peak units. Moving ${(dayPeak * 0.3).toFixed(2)} kWh a day out of this window would save roughly ${money(dayPeak * 0.3 * rate * tariff.TOD_ADJUSTMENT * 30)} a month.` });
    }
  }

  // fan health
  const fh = fv.health;
  if (fh.status === "watch" || fh.status === "check") {
    out.push({ id: "fanhealth", sev: "warn", title: `Fan health is ${fh.score}/100`, detail: fh.reasons.join(" ") });
  } else if (fh.status === "healthy" && fh.score != null) {
    out.push({ id: "fanok", sev: "good", title: `Fan health ${fh.score}/100`, detail: "Power and power factor match what this fan normally draws." });
  }

  // bulb switching and life
  if (bv.switches >= 6) out.push({ id: "switch", sev: "info", title: `Bulb switched on ${bv.switches} times today`, detail: "Each switch-on stresses a filament lamp. LED lamps handle frequent switching better." });

  // month and carbon
  if (b.days > 0) {
    const month = b.total * 30;
    out.push({ id: "month", sev: "info", title: `About ${month.toFixed(1)} kWh a month for these two appliances`,
      detail: `Adds about ${money(marginal(twin.config.restUnits, month))} to a bill that already has ${twin.config.restUnits} kWh of other use. That is ${co2Of(month).toFixed(1)} kg of CO2 a month.` });
  }
  return out;
}

function forecast() {
  const days = completeDays();
  const last = days.slice(-14);
  const mean = (arr) => arr.reduce((s, x) => s + x, 0) / (arr.length || 1);
  const dow = (ds) => new Date(ds + "T12:00:00").getDay();

  // backtest: predict each of the last 7 days from the 7 days before it
  const errs = [];
  for (let k = Math.max(7, days.length - 7); k < days.length; k++) {
    const pred = mean(days.slice(k - 7, k).map((d) => d.total));
    if (days[k].total > 0.05) errs.push(Math.abs(days[k].total - pred) / days[k].total);
  }
  const mape = errs.length ? mean(errs) * 100 : null;

  const next = [];
  const base7 = mean(days.slice(-7).map((d) => d.total));
  for (let k = 1; k <= 7; k++) {
    const d = new Date(); d.setDate(d.getDate() + k);
    const ds = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
    const same = last.filter((x) => dow(x.date) === d.getDay()).map((x) => x.total);
    const kwh = same.length >= 2 ? 0.5 * mean(same) + 0.5 * base7 : base7;
    next.push({ date: ds, dow: d.toLocaleDateString("en-IN", { weekday: "short" }), kwh: +kwh.toFixed(3) });
  }
  const measuredDays = days.filter((d) => d.src === "hardware" || d.src === "virtual").length;
  const monthKwh = base7 * 30;
  return {
    history: last.map((d) => ({ date: d.date, kwh: +d.total.toFixed(3), src: d.src })),
    next, mape: mape == null ? null : +mape.toFixed(1), backtestDays: errs.length,
    monthKwh: +monthKwh.toFixed(2), monthCost: +marginal(twin.config.restUnits, monthKwh).toFixed(2),
    measuredDays,
    basis: measuredDays >= 7 ? "measured by the rig" : "demo-generated history (needs 7 measured days to be a real forecast)",
  };
}

function whatif(q) {
  const b = baseDaily();
  const rest = Number.isFinite(+q.rest) ? +q.rest : twin.config.restUnits;
  const num = (x, d, lo, hi) => Math.min(hi, Math.max(lo, Number.isFinite(+x) ? +x : d));
  const bulbHours = b.bulb * 1000 / 60;
  const fanW = 50;
  const fanHours = b.fan * 1000 / fanW;
  const bulbCut = num(q.bulbCut, 0, 0, Math.max(0, bulbHours));
  const fanCut = num(q.fanCut, 0, 0, Math.max(0, fanHours));
  const led = q.led === "1" || q.led === 1 || q.led === true || q.led === "true";
  const down = q.fanDown === "1" || q.fanDown === 1 || q.fanDown === true || q.fanDown === "true";
  const bulbW = led ? 9 : 60;
  const fanW2 = down ? fanW * (38 / 52) : fanW;

  const before = { bulb: bulbHours * 60 / 1000 * 30, fan: fanHours * fanW / 1000 * 30 };
  const after = { bulb: Math.max(0, bulbHours - bulbCut) * bulbW / 1000 * 30, fan: Math.max(0, fanHours - fanCut) * fanW2 / 1000 * 30 };
  const tb = before.bulb + before.fan, ta = after.bulb + after.fan;
  const cb = marginal(rest, tb), ca = marginal(rest, ta);
  return {
    basis: { days: b.days, measuredDays: b.measuredDays, bulbHoursPerDay: +bulbHours.toFixed(2), fanHoursPerDay: +fanHours.toFixed(2), rest },
    before: { ...before, kwh: tb, cost: cb, co2: co2Of(tb) },
    after: { ...after, kwh: ta, cost: ca, co2: co2Of(ta) },
    saving: { kwh: tb - ta, cost: cb - ca, co2: co2Of(tb - ta), pct: tb > 0 ? ((tb - ta) / tb) * 100 : 0, yearCost: (cb - ca) * 12 },
    limits: { bulbMax: +bulbHours.toFixed(1), fanMax: +fanHours.toFixed(1) },
    slabs: tariff.SLABS.map((s) => ({ upto: s.upto === Infinity ? null : s.upto, rate: s.rate })),
  };
}

module.exports = { insights, forecast, whatif, ratePerKwh, marginal, monthlyCost, baseDaily, co2Of };
