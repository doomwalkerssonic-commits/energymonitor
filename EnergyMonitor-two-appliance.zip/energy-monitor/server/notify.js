// Phone / chat notifications. Nothing is sent unless you configure one of these
// environment variables before starting the server:
//   TELEGRAM_BOT_TOKEN + TELEGRAM_CHAT_ID    -> Telegram message
//   ALERT_WEBHOOK_URL                        -> POST {"text": "..."} (Slack, Discord-compatible, ntfy, etc.)
const status = { telegram: false, webhook: false, sent: 0, failed: 0, lastError: null, lastText: null, lastAt: null };

function configure() {
  status.telegram = !!(process.env.TELEGRAM_BOT_TOKEN && process.env.TELEGRAM_CHAT_ID);
  status.webhook = !!process.env.ALERT_WEBHOOK_URL;
}
configure();

async function send(text) {
  status.lastText = text; status.lastAt = Date.now();
  const jobs = [];
  if (status.telegram) {
    const url = `https://api.telegram.org/bot${process.env.TELEGRAM_BOT_TOKEN}/sendMessage`;
    jobs.push(fetch(url, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: process.env.TELEGRAM_CHAT_ID, text }),
    }));
  }
  if (status.webhook) {
    jobs.push(fetch(process.env.ALERT_WEBHOOK_URL, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, content: text }),
    }));
  }
  for (const j of jobs) {
    try { const r = await j; if (r.ok) status.sent++; else { status.failed++; status.lastError = "HTTP " + r.status; } }
    catch (e) { status.failed++; status.lastError = String(e.message || e); }
  }
}

module.exports = { send, status };
