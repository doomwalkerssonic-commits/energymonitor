// Built-in appliance simulator, used when no ESP32 is posting.
// It models the two demo loads with believable physics so every software feature
// can be developed and demonstrated without hardware.
const FAN = { 1: { w: 38, pf: 0.82 }, 2: { w: 52, pf: 0.88 }, 3: { w: 68, pf: 0.91 } };

const s = {
  bulbOn: true, fanSpeed: 2,
  drag: 0, dragTarget: 0,        // fan bearing friction / dust, 0..1
  sag: false,                    // mains voltage sag
  story: null,                   // running scripted demo
};

const noise = (a) => (Math.random() - 0.5) * a;

function mains() {
  const v = 230 + 3 * Math.sin(Date.now() / 4000) + noise(1.2) - (s.sag ? 26 : 0);
  return v;
}

function reading(id, v) {
  if (id === "bulb") {
    if (!s.bulbOn) return { p: 0, i: 0, pf: 0 };
    const p = 60 * Math.pow(v / 230, 1.5) + noise(0.4);   // incandescent: P ~ V^1.5
    return { p, i: p / v, pf: 1.0 };
  }
  const f = FAN[s.fanSpeed];
  if (!f) return { p: 0, i: 0, pf: 0 };
  const p = f.w * (1 + 0.30 * s.drag) * (v / 230) + noise(0.5);
  const pf = Math.max(0.5, f.pf - 0.07 * s.drag + noise(0.01));
  return { p, i: p / (v * pf), pf };
}

function step() { s.drag += (s.dragTarget - s.drag) * 0.1; }

// One mains cycle (or two) as the ESP32 would capture it, rebuilt from RMS values.
// The fan current has a small 3rd/5th harmonic content; the bulb is a pure resistor.
function synth(id, rec, cycles = 2, N = 128) {
  const pf = Math.min(1, Math.max(0.05, rec.pf || 1));
  const phi = Math.acos(pf);
  const thd = id === "fan" ? 0.05 : 0.006;
  const i1 = rec.i * Math.SQRT2 / Math.sqrt(1 + thd * thd);
  const v = [], i = [];
  for (let k = 0; k < N * cycles; k++) {
    const th = (2 * Math.PI * k) / N;
    v.push(+(rec.v * Math.SQRT2 * (Math.sin(th) - 0.018 * Math.sin(3 * th)) + noise(1.2)).toFixed(2));
    const ith = th - phi;
    i.push(+(rec.i === 0 ? noise(0.01) :
      i1 * (Math.sin(ith) + thd * (0.8 * Math.sin(3 * ith + 0.4) + 0.5 * Math.sin(5 * ith + 1.1))) + noise(0.016)).toFixed(4));
  }
  return { v, i, n: N * cycles, cycles };
}

// ---- Scripted demo story (about 100 s) ----
const STORY = [
  [0,  "Bulb on, fan off. Clean start.",             () => { s.bulbOn = true; s.fanSpeed = 0; s.dragTarget = 0; s.drag = 0; s.sag = false; }],
  [6,  "Fan switched on: low speed.",                 () => { s.fanSpeed = 1; }],
  [13, "Fan moves to medium.",                        () => { s.fanSpeed = 2; }],
  [21, "Fan moves to high.",                          () => { s.fanSpeed = 3; }],
  [29, "Back to medium.",                             () => { s.fanSpeed = 2; }],
  [36, "Fault: bearing friction starts building up.", () => { s.dragTarget = 1; }],
  [70, "Fan cleaned and oiled, friction removed.",    () => { s.dragTarget = 0; }],
  [78, "Fault: mains voltage sags to about 204 V.",   () => { s.sag = true; }],
  [88, "Voltage recovers.",                           () => { s.sag = false; }],
  [100, "Story finished.",                             () => {}],
];

function startStory(hooks) {
  stopStory();
  const run = { t0: Date.now(), step: 0, label: STORY[0][1], timers: [], total: STORY[STORY.length - 1][0] };
  hooks && hooks.begin && hooks.begin();
  STORY.forEach(([at, label, fn], idx) => {
    run.timers.push(setTimeout(() => {
      fn(); run.step = idx; run.label = label;
      if (idx === STORY.length - 1) { hooks && hooks.end && hooks.end(); s.story = null; }
    }, at * 1000));
  });
  run.hooks = hooks;
  s.story = run;
}

function stopStory() {
  if (s.story) { s.story.timers.forEach(clearTimeout); s.story.hooks && s.story.hooks.end && s.story.hooks.end(); s.story = null; }
}

function storyInfo() {
  if (!s.story) return { running: false };
  return { running: true, label: s.story.label, step: s.story.step, steps: STORY.length,
           elapsed: Math.round((Date.now() - s.story.t0) / 1000), total: s.story.total };
}

module.exports = { s, FAN, mains, reading, step, synth, startStory, stopStory, storyInfo };
