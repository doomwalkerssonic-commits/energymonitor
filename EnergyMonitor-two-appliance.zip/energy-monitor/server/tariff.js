// UPPCL LMV-1 (Urban Domestic) tariff, FY 2026-27 — verified telescopic slab rates.
// Source: UPERC-approved schedule, identical across all UP DISCOMs (Lucknow/KESCO included).
const SLABS = [
  { upto: 150, rate: 5.50 },
  { upto: 300, rate: 6.00 },
  { upto: 500, rate: 6.50 },
  { upto: Infinity, rate: 7.00 },
];

const FIXED_CHARGE_PER_KW = 110;   // Rs per kW of sanctioned load, per month
const ELECTRICITY_DUTY = 0.05;     // ~5%
const TRUE_UP_PER_UNIT = 0.15;     // FPPAS surcharge, Rs per unit
const METER_RENT = 50;             // Rs per month
const SANCTIONED_LOAD_KW = 6;      // realistic connection size for a household with 2 ACs + geyser

// Time-of-Day overlay — modeled on the Ministry of Power's national ToD framework
// (peak hours: +10-20% surcharge; solar/off-peak hours: 10-20% rebate). UPPCL's exact
// published clock-hour boundaries for Lucknow were not available, so representative
// hours are used here and documented as such — this is disclosed in the report.
const PEAK_HOURS = new Set([18, 19, 20, 21]);       // evening peak
const SOLAR_HOURS = new Set([9, 10, 11, 12, 13, 14, 15, 16]); // 8-hour solar window
const TOD_ADJUSTMENT = 0.15; // 15%, within the 10-20% national band

function classifyHour(hour) {
  if (PEAK_HOURS.has(hour)) return "peak";
  if (SOLAR_HOURS.has(hour)) return "solar";
  return "normal";
}

// Telescopic slab energy charge for a given total units consumed
function slabEnergyCharge(units) {
  let remaining = units;
  let lower = 0;
  let charge = 0;
  for (const slab of SLABS) {
    const band = Math.max(0, Math.min(remaining, slab.upto - lower));
    charge += band * slab.rate;
    remaining -= band;
    lower = slab.upto;
    if (remaining <= 0) break;
  }
  return charge;
}

function blendedRate(units) {
  if (units <= 0) return SLABS[0].rate;
  return slabEnergyCharge(units) / units;
}

// unitsByBucket: { normal: kWh, peak: kWh, solar: kWh }
function computeBill(unitsByBucket) {
  const totalUnits = unitsByBucket.normal + unitsByBucket.peak + unitsByBucket.solar;
  const baseEnergyCharge = slabEnergyCharge(totalUnits);
  const rate = blendedRate(totalUnits);

  const peakSurcharge = unitsByBucket.peak * rate * TOD_ADJUSTMENT;
  const solarRebate = unitsByBucket.solar * rate * TOD_ADJUSTMENT;
  const todNet = peakSurcharge - solarRebate;

  const energyCharge = baseEnergyCharge + todNet;
  // unitsByBucket resets every simulated day, so fixed charge and meter rent —
  // which are real monthly costs — are prorated to a daily share for this view.
  const monthlyFixedCharge = FIXED_CHARGE_PER_KW * SANCTIONED_LOAD_KW;
  const monthlyMeterRent = METER_RENT;
  const fixedCharge = monthlyFixedCharge / 30;
  const meterRentDaily = monthlyMeterRent / 30;
  const trueUp = totalUnits * TRUE_UP_PER_UNIT;
  const dutyable = energyCharge + trueUp;
  const duty = dutyable * ELECTRICITY_DUTY;
  const total = energyCharge + fixedCharge + trueUp + duty + meterRentDaily;

  return {
    totalUnits: Number(totalUnits.toFixed(3)),
    unitsByBucket,
    blendedRate: Number(rate.toFixed(2)),
    baseEnergyCharge: Number(baseEnergyCharge.toFixed(2)),
    peakSurcharge: Number(peakSurcharge.toFixed(2)),
    solarRebate: Number(solarRebate.toFixed(2)),
    energyCharge: Number(energyCharge.toFixed(2)),
    fixedCharge: Number(fixedCharge.toFixed(2)),
    trueUp: Number(trueUp.toFixed(2)),
    duty: Number(duty.toFixed(2)),
    meterRent: Number(meterRentDaily.toFixed(2)),
    monthlyFixedCharge, monthlyMeterRent,
    total: Number(total.toFixed(2)),
  };
}

module.exports = { classifyHour, computeBill, slabEnergyCharge, blendedRate, TRUE_UP_PER_UNIT, ELECTRICITY_DUTY, SLABS, FIXED_CHARGE_PER_KW, SANCTIONED_LOAD_KW, PEAK_HOURS, SOLAR_HOURS, TOD_ADJUSTMENT };
