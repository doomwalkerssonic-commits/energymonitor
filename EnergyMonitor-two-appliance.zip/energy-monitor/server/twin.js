// The "digital twin" core: one object that knows the live state of both appliances,
// where the numbers came from, what is normal for each appliance, and what changed.
//
// Data per appliance every second:
//   reading  -> from the ESP32 if it is posting, otherwise from the built-in simulator
//   state    -> OFF / ON (bulb) or OFF / LOW / MEDIUM / HIGH (fan), found from power steps
//   health   -> deviation from what this appliance normally draws in that state
//   alerts   -> edge-triggered, with hysteresis, optionally pushed to a phone
const fs = require("fs");
const path = require("path");
const hw = require("./hardware");
const sim = require("./sim");
const tariff = require("./tariff");
const notify = require("./notify");

const FILE = path.join(process.env.DATA_DIR || path.join(__dirname, "data"), "twin.json");
const IDS = ["bulb", "fan"];
const LABEL = { bulb: "Bulb", fan: "Table fan" };
const STATE_LABEL = { off: "OFF", on: "ON", low: "LOW", med: "MEDIUM", high: "HIGH" };
const V_EXP = { bulb: 1.5, fan: 1.0 };        // how power scales with voltage (used to correct to 230 V)
const RING_MAX = 3600;                         // one hour at 1 Hz

const DEFAULT_CONFIG = {
  forceSim: false,        // use the demo simulator even if hardware is posting
  leftOnMinutes: 240,     // "left on" alert
  quietFrom: 23, quietTo: 5,   // night-use alert window (hours)
  overI: 4.5,             // A; the ACS712-05B tops out at 5 A
  underV: 212, overV: 248,
  dragWarn: 0.20,         // fan/bulb drawing 20% above its learned normal
  restUnits: 150,         // kWh/month used by the rest of the building (decides the tariff slab)
  co2: 0.71,              // kg CO2 per kWh, approximate Indian grid average
};

const factoryBaseline = () => ({
  bulb: { on: { w: 60, pf: 1.0, n: 120 } },
  fan: { low: { w: 38, pf: 0.82, n: 120 }, med: { w: 52, pf: 0.88, n: 120 }, high: { w: 68, pf: 0.91, n: 120 } },
});

let config = { ...DEFAULT_CONFIG };
let baseline = factoryBaseline();
let hours = {};          // "YYYY-MM-DD HH" -> { bulb, fan, src }
let alerts = [];         // newest first
let alertSeq = 1;
const activeAlert = {};  // key -> alert id
const ring = [];         // { t, bulb, fan, v }
const tl = { bulb: [], fan: [] };   // state segments { s, from, to }
const devHist = { bulb: [], fan: [] };  // { t, dev, pf }
let lastTick = Date.now();
let day = dayKey(new Date());
let dirty = false;

const A = {};
for (const id of IDS) {
  A[id] = {
    id, rec: null, online: false, state: "off", stateSince: Date.now(), onSince: null,
    pHist: [], devS: 0, dragSecs: 0, switches: 0, runtime: { on: 0, low: 0, med: 0, high: 0 },
    peakW: 0, wh: 0, offlineSecs: 0,
  };
}
let sharedV = 230, sharedF = 50;

function pad(n) { return String(n).padStart(2, "0"); }
function dayKey(d) { return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`; }
function hourKey(d) { return `${dayKey(d)} ${pad(d.getHours())}`; }

// ---------- persistence ----------
function load() {
  try {
    const j = JSON.parse(fs.readFileSync(FILE, "utf8"));
    config = { ...DEFAULT_CONFIG, ...(j.config || {}) };
    hours = j.hours || {};
    alerts = j.alerts || [];
    alertSeq = (alerts[0] && alerts[0].id + 1) || 1;
    if (j.baseline && j.baseline.bulb && j.baseline.fan) baseline = j.baseline;
    if (j.counters && j.counters.day === day) {
      for (const id of IDS) Object.assign(A[id], j.counters[id] || {});
    }
  } catch (e) { /* first run */ }
}

function save() {
  try {
    const counters = { day };
    for (const id of IDS) {
      const a = A[id];
      counters[id] = { switches: a.switches, runtime: a.runtime, peakW: a.peakW, wh: a.wh };
    }
    fs.mkdirSync(path.dirname(FILE), { recursive: true });
    fs.writeFileSync(FILE, JSON.stringify({ config, hours, alerts: alerts.slice(0, 60), baseline, counters }));
    dirty = false;
  } catch (e) { console.error("save failed:", e.message); }
}

// ---------- demo history (clearly labelled "seed") ----------
function rng(seed) {
  let a = seed >>> 0;
  return () => { a |= 0; a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}

function seedHistory() {
  const today = new Date();
  for (let back = 14; back >= 1; back--) {
    const d = new Date(today.getFullYear(), today.getMonth(), today.getDate() - back);
    const dk = dayKey(d);
    if (Object.keys(hours).some((k) => k.startsWith(dk))) continue;
    const r = rng(d.getFullYear() * 1000 + d.getMonth() * 40 + d.getDate());
    const weekend = d.getDay() === 0 || d.getDay() === 6;
    const hot = 0.8 + 0.3 * r();
    for (let h = 0; h < 24; h++) {
      let b = 0, f = 0;
      if (h >= 18 && h <= 22) b = 0.060 * (0.88 + 0.12 * r());
      else if (h === 23 && r() < 0.7) b = 0.060 * (0.4 + 0.6 * r());
      else if ((h === 5 || h === 6) && r() < 0.4) b = 0.060 * (0.3 + 0.7 * r());
      else if (weekend && h >= 9 && h <= 11 && r() < 0.3) b = 0.060 * r();
      if (h >= 12 && h <= 16 && r() < 0.85) f = (r() < 0.5 ? 0.038 : 0.052) * hot * (0.85 + 0.3 * r());
      else if (h >= 19 && h <= 23 && r() < 0.9) f = 0.052 * hot * (0.9 + 0.2 * r());
      else if ((h === 0 || h === 1) && r() < 0.3) f = 0.038 * hot;
      if (b || f) hours[`${dk} ${pad(h)}`] = { bulb: +b.toFixed(5), fan: +f.toFixed(5), src: "seed" };
    }
  }
}

// ---------- per-second pipeline ----------
function mode() {
  if (config.forceSim) return "simulated";
  return hw.seen() ? "hardware" : "simulated";
}

function classify(id, p230) {
  if (p230 < (id === "bulb" ? 2 : 3)) return "off";
  if (id === "bulb") return "on";
  const b = baseline.fan;
  if (p230 < (b.low.w + b.med.w) / 2) return "low";
  if (p230 < (b.med.w + b.high.w) / 2) return "med";
  return "high";
}

function setState(a, ns, now) {
  const seg = tl[a.id];
  if (seg.length) seg[seg.length - 1].to = now;
  if (a.state === "off" && ns !== "off") { a.switches++; a.onSince = now; a.dragSecs = 0; }
  if (ns === "off") { a.onSince = null; a.dragSecs = 0; a.devS = 0; }
  a.state = ns; a.stateSince = now;
  seg.push({ s: ns, from: now, to: null });
  const cut = now - 6 * 3600 * 1000;
  while (seg.length > 1 && seg[0].to && seg[0].to < cut) seg.shift();
}

function raise(key, sev, title, detail, appliance) {
  if (activeAlert[key]) return;
  const al = { id: alertSeq++, t: Date.now(), sev, key, appliance: appliance || null, title, detail, active: true, resolvedAt: null };
  alerts.unshift(al); if (alerts.length > 80) alerts.pop();
  activeAlert[key] = al.id; dirty = true;
  notify.send(`EnergyMonitor ${sev === "crit" ? "ALERT" : "notice"}: ${title}. ${detail}`);
}

function clear(key) {
  const id = activeAlert[key];
  if (!id) return;
  const al = alerts.find((x) => x.id === id);
  if (al) { al.active = false; al.resolvedAt = Date.now(); }
  delete activeAlert[key]; dirty = true;
}

function tick() {
  const now = Date.now();
  const dt = Math.min(3, Math.max(0.2, (now - lastTick) / 1000));
  lastTick = now;
  const nd = dayKey(new Date());
  if (nd !== day) {   // midnight: reset daily counters
    day = nd;
    for (const id of IDS) Object.assign(A[id], { switches: 0, peakW: 0, wh: 0, runtime: { on: 0, low: 0, med: 0, high: 0 } });
  }

  const m = mode();
  sim.step();
  const simV = sim.mains();
  let vSeen = null;
  for (const id of IDS) {
    const a = A[id];
    let rec = null;
    if (m === "hardware") {
      const r = hw.fresh(id);
      if (r) {
        const s = r.v * r.i;
        const p = Math.min(r.p, s || r.p);
        rec = { v: r.v, i: r.i, p, f: r.f || 50, pf: r.pf != null ? r.pf : (s > 0 ? p / s : 0),
                src: /virtual/.test(r.src) ? "virtual" : "hardware" };
        vSeen = r.v; sharedF = rec.f;
      }
    } else {
      const r = sim.reading(id, simV);
      rec = { v: simV, i: r.i, p: r.p, f: 50, pf: r.pf, src: "simulated" };
      vSeen = simV;
    }
    a.online = !!rec;
    if (!rec) {
      a.rec = { v: 0, i: 0, p: 0, f: 0, pf: 0, s: 0, q: 0, src: "offline" };
      a.offlineSecs += dt;
      continue;
    }
    a.offlineSecs = 0;
    rec.s = rec.v * rec.i;
    rec.q = Math.sqrt(Math.max(0, rec.s * rec.s - rec.p * rec.p));
    a.rec = rec;

    const p230 = rec.p * Math.pow(230 / rec.v, V_EXP[id]);
    a.pHist.push(p230); if (a.pHist.length > 4) a.pHist.shift();
    const prev2 = a.pHist.length >= 3 ? a.pHist[a.pHist.length - 3] : null;
    const minOn = id === "bulb" ? 2 : 3;
    const step = prev2 == null ? true : (Math.abs(p230 - prev2) > 5 || ((p230 < minOn) !== (prev2 < minOn)));
    if (!tl[id].length) { setState(a, classify(id, p230), now); a.switches = Math.max(0, a.switches - (a.state === "off" ? 0 : 1)); }
    else if (step) {
      const ns = classify(id, p230);
      if (ns !== a.state) setState(a, ns, now);
    }

    // deviation from learned normal
    let dev = 0;
    const base = baseline[id][a.state];
    if (a.state !== "off" && base) {
      dev = (p230 - base.w) / base.w;
      const age = (now - a.stateSince) / 1000;
      const learning = base.n < 120;
      if (age > 10 && (learning || Math.abs(a.devS) < 0.10)) {
        const alpha = learning ? 0.05 : 0.0002;
        base.w += alpha * (p230 - base.w);
        base.pf += alpha * (rec.pf - base.pf);
        base.n++;
      }
    }
    a.devS += 0.1 * (dev - a.devS);

    // counters
    const wh = (rec.p * dt) / 3600;
    a.wh += wh;
    a.peakW = Math.max(a.peakW, rec.p);
    if (a.state !== "off") a.runtime[a.state] += dt;
    const hk = hourKey(new Date());
    const hb = hours[hk] || (hours[hk] = { bulb: 0, fan: 0, src: "demo" });
    hb[id] += wh / 1000;
    if (rec.src === "hardware" || rec.src === "virtual") hb.src = rec.src; else if (hb.src === "seed") hb.src = "demo";
    dirty = true;
  }
  if (vSeen != null) sharedV = vSeen;

  const b = A.bulb.rec, f = A.fan.rec;
  ring.push({ t: now, bulb: b.p, fan: f.p, v: sharedV });
  if (ring.length > RING_MAX) ring.shift();
  if (Math.floor(now / 5000) !== Math.floor((now - dt * 1000) / 5000)) {
    for (const id of IDS) {
      if (!A[id].online) continue;
      devHist[id].push({ t: now, dev: A[id].state === "off" ? null : +A[id].devS.toFixed(4), pf: A[id].state === "off" ? null : +A[id].rec.pf.toFixed(3) });
      if (devHist[id].length > 360) devHist[id].shift();
    }
  }
  evaluateAlerts(now, m);
}

function evaluateAlerts(now, m) {
  const hr = new Date().getHours();
  const quiet = config.quietFrom > config.quietTo ? (hr >= config.quietFrom || hr < config.quietTo) : (hr >= config.quietFrom && hr < config.quietTo);

  // hardware went quiet
  if (m === "hardware") {
    const off = IDS.every((id) => !A[id].online) && A.bulb.offlineSecs > 8;
    if (off) raise("offline", "crit", "ESP32 stopped sending data", "No reading for over 8 seconds. Check Wi-Fi, power to the ESP32 and the server address.");
    else if (IDS.some((id) => A[id].online)) clear("offline");
  } else clear("offline");

  const on = IDS.filter((id) => A[id].online);
  if (on.length) {
    const v = sharedV;
    if (v < config.underV) raise("under", "warn", `Low mains voltage: ${v.toFixed(0)} V`, `Below the ${config.underV} V limit. Motors and heaters run hotter and the fan may stall.`);
    else if (v > config.underV + 3) clear("under");
    if (v > config.overV) raise("over", "warn", `High mains voltage: ${v.toFixed(0)} V`, `Above the ${config.overV} V limit.`);
    else if (v < config.overV - 3) clear("over");
  }

  for (const id of IDS) {
    const a = A[id];
    if (!a.online) continue;
    const r = a.rec;
    if (r.i > config.overI) raise("oc:" + id, "crit", `${LABEL[id]}: current ${r.i.toFixed(2)} A`, `Above the ${config.overI} A limit of the current sensor. Check for a short circuit or the wrong load.`, id);
    else if (r.i < config.overI * 0.95) clear("oc:" + id);

    if (id === "fan" && a.state !== "off") {
      const base = baseline.fan[a.state];
      if (a.devS > config.dragWarn && base && base.n >= 20) {
        a.dragSecs++;
        if (a.dragSecs >= 8) {
          const p230 = r.p * (230 / r.v);
          raise("drag:fan", "warn", `Fan is drawing ${(a.devS * 100).toFixed(0)}% more than normal`,
            `At ${STATE_LABEL[a.state].toLowerCase()} speed it normally draws ${base.w.toFixed(0)} W (corrected to 230 V); now ${p230.toFixed(0)} W with power factor ${r.pf.toFixed(2)}. Likely bearing friction, dust build-up or a weak capacitor.`, "fan");
        }
      } else if (a.devS < 0.10) { a.dragSecs = 0; clear("drag:fan"); }
    }

    const leftLong = a.onSince && (now - a.onSince) / 60000 > config.leftOnMinutes;
    if (leftLong) {
      const mins = Math.round((now - a.onSince) / 60000);
      raise("left:" + id, "warn", `${LABEL[id]} has been on for ${mins >= 120 ? (mins / 60).toFixed(1) + " hours" : mins + " min"}`, `Longer than your ${config.leftOnMinutes >= 60 ? (config.leftOnMinutes / 60).toFixed(1) + " hour" : config.leftOnMinutes + " min"} limit. Switch it off if nobody needs it.`, id);
    } else clear("left:" + id);

    if (quiet && a.onSince && (now - a.onSince) > 300000) raise("night:" + id, "info", `${LABEL[id]} running at night`, `It has been on for more than 5 minutes during the ${pad(config.quietFrom)}:00 to ${pad(config.quietTo)}:00 quiet window.`, id);
    else if (!a.onSince || !quiet) clear("night:" + id);
  }
}

// ---------- readers used by the API ----------
function todayKwh(id) {
  const dk = dayKey(new Date());
  let s = 0;
  for (const k in hours) if (k.startsWith(dk)) s += hours[k][id] || 0;
  return s;
}

function dailyTotals() {
  const m = {};
  for (const k in hours) {
    const d = k.slice(0, 10);
    const o = m[d] || (m[d] = { date: d, bulb: 0, fan: 0, total: 0, src: "seed", hours: {} });
    const h = hours[k];
    o.bulb += h.bulb; o.fan += h.fan; o.total += h.bulb + h.fan;
    o.hours[+k.slice(11)] = h.bulb + h.fan;
    if (h.src === "hardware" || h.src === "virtual") o.src = h.src;
    else if (h.src === "demo" && o.src === "seed") o.src = "demo";
  }
  return Object.values(m).sort((x, y) => (x.date < y.date ? -1 : 1));
}

function segments(sinceMs) {
  const now = Date.now(), from = now - sinceMs;
  const out = {};
  for (const id of IDS) {
    out[id] = tl[id].filter((s) => (s.to || now) > from).map((s) => ({ s: s.s, from: Math.max(s.from, from), to: s.to || now }));
  }
  return { from, to: now, segs: out };
}

function applianceView(id) {
  const a = A[id], r = a.rec;
  const base = baseline[id][a.state];
  const p230 = r && r.v ? r.p * Math.pow(230 / r.v, V_EXP[id]) : 0;
  return {
    id, label: LABEL[id], online: a.online, src: r ? r.src : "offline",
    state: a.state, stateLabel: STATE_LABEL[a.state], stateSince: a.stateSince,
    v: r ? r.v : 0, i: r ? r.i : 0, p: r ? r.p : 0, s: r ? r.s : 0, q: r ? r.q : 0, pf: r ? r.pf : 0, f: r ? r.f : 0,
    p230, expected: base ? base.w : null, expectedPf: base ? base.pf : null,
    dev: a.state === "off" ? 0 : a.devS,
    kwhToday: todayKwh(id), switches: a.switches, runtime: a.runtime, peakW: a.peakW,
    onForMin: a.onSince ? (Date.now() - a.onSince) / 60000 : 0,
    health: healthOf(id),
  };
}

function healthOf(id) {
  const a = A[id], r = a.rec;
  if (!a.online) return { score: null, status: "offline", reasons: ["No data from this channel."] };
  if (a.state === "off") return { score: null, status: "idle", reasons: ["Switched off. Health is judged while it runs."] };
  const base = baseline[id][a.state];
  const reasons = [];
  const devPart = Math.min(60, Math.max(0, a.devS) * 200);
  const pfDrop = Math.max(0, base.pf - r.pf);
  const pfPart = Math.min(25, pfDrop * 250);
  const lowPart = a.devS < -0.15 ? Math.min(20, (-a.devS - 0.15) * 100) : 0;
  const score = Math.round(Math.max(0, 100 - devPart - pfPart - lowPart));
  if (a.devS > 0.05) reasons.push(`Drawing ${(a.devS * 100).toFixed(0)}% above its normal ${base.w.toFixed(0)} W.`);
  if (a.devS < -0.15) reasons.push(`Drawing ${(-a.devS * 100).toFixed(0)}% below normal. A failing element or loose connection is possible.`);
  if (pfDrop > 0.03) reasons.push(`Power factor ${r.pf.toFixed(2)} is ${pfDrop.toFixed(2)} below normal.`);
  if (!reasons.length) reasons.push("Matches its learned normal for this state.");
  const status = score >= 85 ? "healthy" : score >= 60 ? "watch" : "check";
  return { score, status, reasons, baselineLearned: base.n >= 120 };
}

function powerSeries(sec, bucket) {
  const now = Date.now();
  const pts = ring.filter((p) => p.t >= now - sec * 1000);
  const out = [];
  for (let i = 0; i < pts.length; i += bucket) {
    const g = pts.slice(i, i + bucket);
    const avg = (k) => g.reduce((s, x) => s + x[k], 0) / g.length;
    out.push({ t: g[g.length - 1].t, bulb: +avg("bulb").toFixed(2), fan: +avg("fan").toFixed(2), v: +avg("v").toFixed(1) });
  }
  return out;
}

function scope(id) {
  const a = A[id];
  if (!a || !a.online) return { id, src: "offline", n: 0, v: [], i: [] };
  if (mode() === "hardware") {
    const w = hw.freshWave(id);
    if (w) {
      let v = w.v, i = w.i;
      if (w.cycles < 2) { v = v.concat(v); i = i.concat(i); }
      return { id, src: "raw", cycles: Math.max(2, w.cycles), n: v.length, v, i };
    }
  }
  const s = sim.synth(id, a.rec);
  return { id, src: "reconstructed", cycles: s.cycles, n: s.n, v: s.v, i: s.i };
}

function control(c) {
  if (mode() !== "simulated") return false;
  if (c.bulb != null) sim.s.bulbOn = !!c.bulb;
  if (c.fan != null) sim.s.fanSpeed = Math.max(0, Math.min(3, Math.round(c.fan)));
  if (c.drag != null) sim.s.dragTarget = c.drag ? 1 : 0;
  if (c.sag != null) sim.s.sag = !!c.sag;
  return true;
}

function relearn(id) {
  for (const k in baseline[id]) baseline[id][k].n = 0;
  dirty = true;
}

function resetBaseline() { baseline = factoryBaseline(); dirty = true; }

function setConfig(c) {
  for (const k of Object.keys(DEFAULT_CONFIG)) {
    if (c[k] == null) continue;
    if (typeof DEFAULT_CONFIG[k] === "boolean") config[k] = !!c[k];
    else if (Number.isFinite(+c[k])) config[k] = +c[k];
  }
  dirty = true;
  return config;
}

function storyHooks() {
  let saved = null;
  return {
    begin() { saved = config.leftOnMinutes; config.leftOnMinutes = 1; Object.keys(activeAlert).forEach((k) => /^left:/.test(k) && clear(k)); },
    end() { if (saved != null) { config.leftOnMinutes = saved; saved = null; } },
  };
}

function start() {
  load();
  seedHistory();
  setInterval(tick, 1000);
  setInterval(() => { if (dirty) save(); }, 30000);
  process.on("SIGINT", () => { save(); process.exit(0); });
  process.on("SIGTERM", () => { save(); process.exit(0); });
  for (let i = 0; i < 3; i++) tick();
  save();
}

module.exports = {
  IDS, LABEL, STATE_LABEL, start, mode, applianceView, powerSeries, segments, scope, control, relearn, resetBaseline,
  setConfig, dailyTotals, todayKwh, storyHooks, save,
  get config() { return config; }, get alerts() { return alerts; }, get baseline() { return baseline; },
  get hours() { return hours; }, get sharedV() { return sharedV; }, get sharedF() { return sharedF; },
  devHist: (id) => devHist[id], runtime: (id) => A[id].runtime,
};
