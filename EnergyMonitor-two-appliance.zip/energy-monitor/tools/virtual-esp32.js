// Virtual ESP32: behaves like the real board (bulb + fan, ZMPT101B + 2 x ACS712).
// It generates paired voltage/current samples for one mains cycle, runs the SAME maths the
// firmware will run (RMS, real power, PF), and posts the result every second.
//
//   node tools/virtual-esp32.js                    (server at http://localhost:3000)
//   node tools/virtual-esp32.js http://192.168.1.20:3000
//
// Keys: b bulb on/off | 0 1 2 3 fan off/low/med/high | f fan friction | s voltage sag
//       d drop Wi-Fi for 8 s | q quit
const BASE = process.argv[2] || process.env.SERVER || "http://localhost:3000";
const URL = BASE.replace(/\/$/, "") + "/api/hardware/reading";
const N = 128;                              // samples per mains cycle

let bulbOn = true, fanSpeed = 2, friction = false, sag = false, dragNow = 0, droppedUntil = 0;
const FAN = { 1: { w: 38, pf: 0.82 }, 2: { w: 52, pf: 0.88 }, 3: { w: 68, pf: 0.91 } };
const kwh = { bulb: 0, fan: 0 };
let sent = 0, failed = 0;
const noise = (a) => (Math.random() - 0.5) * a;

// What the sensors would see (volts and amps), one cycle.
function capture(id, Vrms, Irms, pf, thd) {
  const phi = Math.acos(Math.min(1, Math.max(0.05, pf)));
  const i1 = Irms * Math.SQRT2 / Math.sqrt(1 + thd * thd);
  const v = [], i = [];
  for (let k = 0; k < N; k++) {
    const th = (2 * Math.PI * k) / N, ith = th - phi;
    v.push(Vrms * Math.SQRT2 * (Math.sin(th) - 0.018 * Math.sin(3 * th)) + noise(1.2));
    i.push(Irms === 0 ? noise(0.01) : i1 * (Math.sin(ith) + thd * (0.8 * Math.sin(3 * ith + 0.4) + 0.5 * Math.sin(5 * ith + 1.1))) + noise(0.016));
  }
  return { v, i };
}

// The firmware's maths (see the Scope page).
function measure(w) {
  const mv = w.v.reduce((a, b) => a + b, 0) / N, mi = w.i.reduce((a, b) => a + b, 0) / N;
  let sv = 0, si = 0, sp = 0;
  for (let k = 0; k < N; k++) { const a = w.v[k] - mv, b = w.i[k] - mi; sv += a * a; si += b * b; sp += a * b; }
  const vrms = Math.sqrt(sv / N), irms = Math.sqrt(si / N), p = Math.max(0, sp / N);
  return { vrms, irms, p, pf: vrms * irms > 1e-4 ? Math.min(1, p / (vrms * irms)) : 0 };
}

function load(id, V) {
  if (id === "bulb") {
    if (!bulbOn) return { I: 0, pf: 1, thd: 0.006 };
    const p = 60 * Math.pow(V / 230, 1.5);
    return { I: p / V, pf: 1, thd: 0.006 };
  }
  const f = FAN[fanSpeed];
  if (!f) return { I: 0, pf: 1, thd: 0.05 };
  dragNow += ((friction ? 1 : 0) - dragNow) * 0.1;
  const p = f.w * (1 + 0.30 * dragNow) * (V / 230);
  const pf = Math.max(0.5, f.pf - 0.07 * dragNow);
  return { I: p / (V * pf), pf, thd: 0.05 };
}

async function tick() {
  const V = 230 + 3 * Math.sin(Date.now() / 4000) + noise(1.2) - (sag ? 26 : 0);
  const line = [];
  for (const id of ["bulb", "fan"]) {
    const l = load(id, V);
    const w = capture(id, V, l.I, l.pf, l.thd);
    const m = measure(w);
    kwh[id] += (m.p / 1000) / 3600;
    line.push(`${id} ${m.p.toFixed(1).padStart(5)} W`);
    if (Date.now() < droppedUntil) continue;
    try {
      const res = await fetch(URL, {
        method: "POST", headers: { "Content-Type": "application/json", ...(process.env.DEVICE_KEY ? { "x-device-key": process.env.DEVICE_KEY } : {}) },
        body: JSON.stringify({ id, v: +m.vrms.toFixed(1), i: +m.irms.toFixed(3), p: +m.p.toFixed(1), pf: +m.pf.toFixed(2),
          f: 50.0, kwh: +kwh[id].toFixed(5), src: "virtual-esp32",
          wave: { cycles: 1, v: w.v.map((x) => +x.toFixed(2)), i: w.i.map((x) => +x.toFixed(4)) } }),
      });
      if (res.status === 204) sent++; else { failed++; console.error("\nserver said", res.status, await res.text()); }
    } catch (e) { failed++; }
  }
  const st = Date.now() < droppedUntil ? "WIFI DROPPED" : (failed ? `ok, ${failed} failed` : "online");
  process.stdout.write(`\r${st.padEnd(13)} V ${V.toFixed(1)}  ${line.join("  ")}  fan:${["off", "low", "med", "high"][fanSpeed]}${friction ? "+friction" : ""} bulb:${bulbOn ? "on " : "off"}${sag ? " SAG" : ""}  posts:${sent}   `);
}

console.log(`Virtual ESP32 posting to ${URL}`);
console.log("Keys: b bulb | 0 1 2 3 fan | f friction | s sag | d drop Wi-Fi 8 s | q quit\n");
setInterval(tick, 1000); tick();

if (process.stdin.isTTY) {
  process.stdin.setRawMode(true); process.stdin.resume(); process.stdin.setEncoding("utf8");
  process.stdin.on("data", (k) => {
    if (k === "q" || k === "\u0003") { console.log("\nbye"); process.exit(0); }
    if (k === "b") bulbOn = !bulbOn;
    if ("0123".includes(k)) fanSpeed = Number(k);
    if (k === "f") friction = !friction;
    if (k === "s") sag = !sag;
    if (k === "d") droppedUntil = Date.now() + 8000;
  });
} else {
  console.log("(no keyboard: fan speed cycles every 15 s, friction toggles every 60 s)");
  setInterval(() => { fanSpeed = (fanSpeed % 3) + 1; }, 15000);
  setInterval(() => { friction = !friction; }, 60000);
}
